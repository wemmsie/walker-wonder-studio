# WordPress MySQL database migration
#
# Generated: Wednesday 18. September 2024 02:13 UTC
# Hostname: localhost
# Database: `local`
# URL: //localhost:10004
# Path: /Users/emily.jones/Local Sites/data-automation-professionals/app/public
# Tables: wper_actionscheduler_actions, wper_actionscheduler_claims, wper_actionscheduler_groups, wper_actionscheduler_logs, wper_ce4wp_contacts, wper_commentmeta, wper_comments, wper_links, wper_nfd_data_event_queue, wper_options, wper_postmeta, wper_posts, wper_term_relationships, wper_term_taxonomy, wper_termmeta, wper_terms, wper_usermeta, wper_users, wper_wpforms_logs, wper_wpforms_payment_meta, wper_wpforms_payments, wper_wpforms_tasks_meta, wper_yoast_indexable, wper_yoast_indexable_hierarchy, wper_yoast_migrations, wper_yoast_primary_term, wper_yoast_seo_links
# Table Prefix: wper_
# Post Types: revision, acf-field, acf-field-group, attachment, page, post, resource, wp_global_styles, wp_navigation
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wper_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wper_actionscheduler_actions`;


#
# Table structure of table `wper_actionscheduler_actions`
#

CREATE TABLE `wper_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT '10',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook_status_scheduled_date_gmt` (`hook`(163),`status`,`scheduled_date_gmt`),
  KEY `status_scheduled_date_gmt` (`status`,`scheduled_date_gmt`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_actionscheduler_actions`
#
INSERT INTO `wper_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `priority`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(6, 'action_scheduler/migration_hook', 'complete', '2024-08-13 17:06:24', '2024-08-13 17:06:24', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1723568784;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1723568784;s:19:"scheduled_timestamp";i:1723568784;s:9:"timestamp";i:1723568784;}', 1, 1, '2024-08-13 17:06:28', '2024-08-13 17:06:28', 0, NULL) ;

#
# End of data contents of table `wper_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wper_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wper_actionscheduler_claims`;


#
# Table structure of table `wper_actionscheduler_claims`
#

CREATE TABLE `wper_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_actionscheduler_claims`
#

#
# End of data contents of table `wper_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wper_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wper_actionscheduler_groups`;


#
# Table structure of table `wper_actionscheduler_groups`
#

CREATE TABLE `wper_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_actionscheduler_groups`
#
INSERT INTO `wper_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wpforms') ;

#
# End of data contents of table `wper_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wper_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wper_actionscheduler_logs`;


#
# Table structure of table `wper_actionscheduler_logs`
#

CREATE TABLE `wper_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_actionscheduler_logs`
#
INSERT INTO `wper_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 6, 'action created', '2024-08-13 17:05:24', '2024-08-13 17:05:24'),
(2, 6, 'action started via WP Cron', '2024-08-13 17:06:28', '2024-08-13 17:06:28'),
(3, 6, 'action complete via WP Cron', '2024-08-13 17:06:28', '2024-08-13 17:06:28') ;

#
# End of data contents of table `wper_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wper_ce4wp_contacts`
#

DROP TABLE IF EXISTS `wper_ce4wp_contacts`;


#
# Table structure of table `wper_ce4wp_contacts`
#

CREATE TABLE `wper_ce4wp_contacts` (
  `contact_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `last_name` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `telephone` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `consent` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`contact_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_ce4wp_contacts`
#

#
# End of data contents of table `wper_ce4wp_contacts`
# --------------------------------------------------------



#
# Delete any existing table `wper_commentmeta`
#

DROP TABLE IF EXISTS `wper_commentmeta`;


#
# Table structure of table `wper_commentmeta`
#

CREATE TABLE `wper_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_commentmeta`
#

#
# End of data contents of table `wper_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wper_comments`
#

DROP TABLE IF EXISTS `wper_comments`;


#
# Table structure of table `wper_comments`
#

CREATE TABLE `wper_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_comments`
#
INSERT INTO `wper_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-08-13 17:04:56', '2024-08-13 17:04:56', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wper_comments`
# --------------------------------------------------------



#
# Delete any existing table `wper_links`
#

DROP TABLE IF EXISTS `wper_links`;


#
# Table structure of table `wper_links`
#

CREATE TABLE `wper_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_links`
#

#
# End of data contents of table `wper_links`
# --------------------------------------------------------



#
# Delete any existing table `wper_nfd_data_event_queue`
#

DROP TABLE IF EXISTS `wper_nfd_data_event_queue`;


#
# Table structure of table `wper_nfd_data_event_queue`
#

CREATE TABLE `wper_nfd_data_event_queue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attempts` tinyint(3) NOT NULL DEFAULT '0',
  `reserved_at` datetime DEFAULT NULL,
  `available_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=879 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_nfd_data_event_queue`
#
INSERT INTO `wper_nfd_data_event_queue` ( `id`, `event`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
(869, 'O:32:"NewfoldLabs\\WP\\Module\\Data\\Event":6:{s:8:"category";s:5:"admin";s:3:"key";s:8:"pageview";s:4:"data";a:2:{s:4:"page";s:78:"https://ehy.sgz.mybluehost.me/wp-admin/post.php?post=111&action=edit&message=1";s:10:"page_title";s:13:"Edit Resource";}s:7:"request";a:4:{s:3:"url";s:78:"https://ehy.sgz.mybluehost.me/wp-admin/post.php?post=111&action=edit&message=1";s:10:"page_title";s:13:"Edit Resource";s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724953360;}', 0, NULL, '2024-08-29 17:42:40', '2024-08-29 17:42:40'),
(870, 'a:7:{s:8:"category";s:5:"admin";s:3:"key";s:5:"login";s:4:"data";a:0:{}s:7:"request";a:4:{s:3:"url";s:35:"http://localhost:10004/wp-login.php";s:10:"page_title";N;s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:0;s:5:"login";N;s:4:"role";N;s:6:"locale";s:5:"en_US";}s:4:"time";i:1724953961;s:11:"environment";a:14:{s:5:"brand";s:8:"bluehost";s:11:"cache_level";i:1;s:10:"cloudflare";b:0;s:4:"data";s:5:"2.6.2";s:5:"email";s:27:"admin@ehy.sgz.mybluehost.me";s:8:"hostname";s:20:"box5526.bluehost.com";s:5:"mysql";s:6:"5.7.23";s:6:"origin";s:8:"bluehost";s:3:"php";s:6:"8.2.18";s:6:"plugin";s:6:"3.14.7";s:3:"url";s:22:"http://localhost:10004";s:8:"username";s:8:"ehysgzmy";s:2:"wp";s:5:"6.6.1";s:11:"server_path";s:28:"/home2/ehysgzmy/public_html/";}}', 0, NULL, '2024-08-29 17:52:41', '2024-08-29 17:52:41'),
(871, 'O:32:"NewfoldLabs\\WP\\Module\\Data\\Event":6:{s:8:"category";s:5:"admin";s:3:"key";s:8:"pageview";s:4:"data";a:2:{s:4:"page";s:78:"https://ehy.sgz.mybluehost.me/wp-admin/post.php?post=111&action=edit&message=1";s:10:"page_title";s:13:"Edit Resource";}s:7:"request";a:4:{s:3:"url";s:78:"https://ehy.sgz.mybluehost.me/wp-admin/post.php?post=111&action=edit&message=1";s:10:"page_title";s:13:"Edit Resource";s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724953962;}', 0, NULL, '2024-08-29 17:52:42', '2024-08-29 17:52:42'),
(872, 'O:32:"NewfoldLabs\\WP\\Module\\Data\\Event":6:{s:8:"category";s:5:"admin";s:3:"key";s:8:"pageview";s:4:"data";a:2:{s:4:"page";s:49:"https://ehy.sgz.mybluehost.me/wp-admin/export.php";s:10:"page_title";s:6:"Export";}s:7:"request";a:4:{s:3:"url";s:49:"https://ehy.sgz.mybluehost.me/wp-admin/export.php";s:10:"page_title";s:6:"Export";s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724953971;}', 0, NULL, '2024-08-29 17:52:51', '2024-08-29 17:52:51'),
(873, 'O:32:"NewfoldLabs\\WP\\Module\\Data\\Event":6:{s:8:"category";s:5:"admin";s:3:"key";s:8:"pageview";s:4:"data";a:2:{s:4:"page";s:50:"https://ehy.sgz.mybluehost.me/wp-admin/plugins.php";s:10:"page_title";s:7:"Plugins";}s:7:"request";a:4:{s:3:"url";s:50:"https://ehy.sgz.mybluehost.me/wp-admin/plugins.php";s:10:"page_title";s:7:"Plugins";s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724954006;}', 0, NULL, '2024-08-29 17:53:26', '2024-08-29 17:53:26'),
(874, 'O:32:"NewfoldLabs\\WP\\Module\\Data\\Event":6:{s:8:"category";s:5:"admin";s:3:"key";s:8:"pageview";s:4:"data";a:2:{s:4:"page";s:57:"https://ehy.sgz.mybluehost.me/wp-admin/plugin-install.php";s:10:"page_title";s:11:"Add Plugins";}s:7:"request";a:4:{s:3:"url";s:57:"https://ehy.sgz.mybluehost.me/wp-admin/plugin-install.php";s:10:"page_title";s:11:"Add Plugins";s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724954009;}', 0, NULL, '2024-08-29 17:53:29', '2024-08-29 17:53:29'),
(875, 'a:7:{s:8:"category";s:6:"plugin";s:3:"key";s:16:"plugin_installed";s:4:"data";a:1:{s:7:"plugins";a:8:{i:0;a:7:{s:4:"slug";s:48:"advanced-custom-fields-table-field/acf-table.php";s:7:"version";s:6:"1.3.24";s:5:"title";s:35:"Advanced Custom Fields: Table Field";s:3:"url";s:26:"http://www.johannheyne.de/";s:6:"active";b:1;s:2:"mu";b:0;s:12:"auto_updates";b:1;}i:1;a:7:{s:4:"slug";s:34:"advanced-custom-fields-pro/acf.php";s:7:"version";s:5:"6.3.4";s:5:"title";s:26:"Advanced Custom Fields PRO";s:3:"url";s:36:"https://www.advancedcustomfields.com";s:6:"active";b:1;s:2:"mu";b:0;s:12:"auto_updates";b:1;}i:2;a:7:{s:4:"slug";s:19:"akismet/akismet.php";s:7:"version";s:5:"5.3.3";s:5:"title";s:34:"Akismet Anti-spam: Spam Protection";s:3:"url";s:20:"https://akismet.com/";s:6:"active";b:0;s:2:"mu";b:0;s:12:"auto_updates";b:1;}i:3;a:7:{s:4:"slug";s:31:"seo-checklist/seo-checklist.php";s:7:"version";s:3:"1.0";s:5:"title";s:13:"SEO Checklist";s:3:"url";N;s:6:"active";b:1;s:2:"mu";b:0;s:12:"auto_updates";b:1;}i:4;a:7:{s:4:"slug";s:55:"bluehost-wordpress-plugin/bluehost-wordpress-plugin.php";s:7:"version";s:6:"3.14.7";s:5:"title";s:19:"The Bluehost Plugin";s:3:"url";s:20:"https://bluehost.com";s:6:"active";b:1;s:2:"mu";b:0;s:12:"auto_updates";b:1;}i:5;a:7:{s:4:"slug";s:31:"wp-migrate-db/wp-migrate-db.php";s:7:"version";s:6:"2.6.11";s:5:"title";s:15:"WP Migrate Lite";s:3:"url";s:44:"https://wordpress.org/plugins/wp-migrate-db/";s:6:"active";b:0;s:2:"mu";b:0;s:12:"auto_updates";b:1;}i:6;a:7:{s:4:"slug";s:24:"endurance-page-cache.php";s:7:"version";s:5:"2.2.1";s:5:"title";s:20:"Endurance Page Cache";s:3:"url";N;s:6:"active";b:0;s:2:"mu";b:1;s:12:"auto_updates";b:0;}i:7;a:7:{s:4:"slug";s:7:"sso.php";s:7:"version";s:3:"0.5";s:5:"title";s:3:"SSO";s:3:"url";N;s:6:"active";b:0;s:2:"mu";b:1;s:12:"auto_updates";b:0;}}}s:7:"request";a:4:{s:3:"url";s:46:"http://localhost:10004/wp-admin/admin-ajax.php";s:10:"page_title";N;s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724954020;s:11:"environment";a:14:{s:5:"brand";s:8:"bluehost";s:11:"cache_level";i:1;s:10:"cloudflare";b:0;s:4:"data";s:5:"2.6.2";s:5:"email";s:27:"admin@ehy.sgz.mybluehost.me";s:8:"hostname";s:20:"box5526.bluehost.com";s:5:"mysql";s:6:"5.7.23";s:6:"origin";s:8:"bluehost";s:3:"php";s:6:"8.2.18";s:6:"plugin";s:6:"3.14.7";s:3:"url";s:22:"http://localhost:10004";s:8:"username";s:8:"ehysgzmy";s:2:"wp";s:5:"6.6.1";s:11:"server_path";s:28:"/home2/ehysgzmy/public_html/";}}', 0, NULL, '2024-08-29 17:53:42', '2024-08-29 17:53:42'),
(876, 'O:32:"NewfoldLabs\\WP\\Module\\Data\\Event":6:{s:8:"category";s:6:"plugin";s:3:"key";s:16:"plugin_activated";s:4:"data";a:2:{s:6:"plugin";a:7:{s:4:"slug";s:31:"wp-migrate-db/wp-migrate-db.php";s:7:"version";s:6:"2.6.11";s:5:"title";s:15:"WP Migrate Lite";s:3:"url";s:44:"https://wordpress.org/plugins/wp-migrate-db/";s:6:"active";b:1;s:2:"mu";b:0;s:12:"auto_updates";b:1;}s:12:"network_wide";b:0;}s:7:"request";a:4:{s:3:"url";s:127:"https://ehy.sgz.mybluehost.me/wp-admin/plugins.php?_wpnonce=11757f03d2&action=activate&plugin=wp-migrate-db%2Fwp-migrate-db.php";s:10:"page_title";N;s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724954024;}', 0, NULL, '2024-08-29 17:53:44', '2024-08-29 17:53:44'),
(877, 'O:32:"NewfoldLabs\\WP\\Module\\Data\\Event":6:{s:8:"category";s:5:"admin";s:3:"key";s:8:"pageview";s:4:"data";a:2:{s:4:"page";s:78:"https://ehy.sgz.mybluehost.me/wp-admin/plugins.php?plugin_status=all&paged=1&s";s:10:"page_title";s:7:"Plugins";}s:7:"request";a:4:{s:3:"url";s:78:"https://ehy.sgz.mybluehost.me/wp-admin/plugins.php?plugin_status=all&paged=1&s";s:10:"page_title";s:7:"Plugins";s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724954024;}', 0, NULL, '2024-08-29 17:53:44', '2024-08-29 17:53:44'),
(878, 'O:32:"NewfoldLabs\\WP\\Module\\Data\\Event":6:{s:8:"category";s:5:"admin";s:3:"key";s:8:"pageview";s:4:"data";a:2:{s:4:"page";s:67:"https://ehy.sgz.mybluehost.me/wp-admin/tools.php?page=wp-migrate-db";s:10:"page_title";s:10:"WP Migrate";}s:7:"request";a:4:{s:3:"url";s:67:"https://ehy.sgz.mybluehost.me/wp-admin/tools.php?page=wp-migrate-db";s:10:"page_title";s:10:"WP Migrate";s:10:"user_agent";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:2:"ip";s:10:"24.13.2.32";}s:4:"user";a:4:{s:2:"id";i:2;s:5:"login";s:2:"mj";s:4:"role";s:13:"administrator";s:6:"locale";s:5:"en_US";}s:4:"time";i:1724954028;}', 0, NULL, '2024-08-29 17:53:48', '2024-08-29 17:53:48') ;

#
# End of data contents of table `wper_nfd_data_event_queue`
# --------------------------------------------------------



#
# Delete any existing table `wper_options`
#

DROP TABLE IF EXISTS `wper_options`;


#
# Table structure of table `wper_options`
#

CREATE TABLE `wper_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=4989 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_options`
#
INSERT INTO `wper_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'cron', 'a:17:{i:1726628699;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1726630989;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"e0823129652435758b34f351da774cd1";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:118;}}}}i:1726635896;a:1:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1726635899;a:2:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1726635943;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1726679096;a:2:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1726679113;a:2:{s:13:"nfd_data_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:20:"jetpack_v2_heartbeat";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1726679226;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1726679232;a:1:{s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1726679235;a:1:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1726679538;a:1:{s:40:"monsterinsights_feature_feedback_checkin";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1726682374;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1726850534;a:1:{s:35:"monsterinsights_usage_tracking_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1727197501;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1727197938;a:1:{s:46:"monsterinsights_feature_feedback_clear_expired";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1727200632;a:1:{s:27:"acf_update_site_health_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'auto'),
(2, 'siteurl', 'http://localhost:10004', 'on'),
(3, 'home', 'http://localhost:10004', 'on'),
(4, 'blogname', 'Data Automation Professionals', 'yes'),
(5, 'blogdescription', 'Unlock the power of your data', 'on'),
(6, 'users_can_register', '0', 'on'),
(7, 'admin_email', 'admin@ehy.sgz.mybluehost.me', 'on'),
(8, 'start_of_week', '1', 'on'),
(9, 'use_balanceTags', '0', 'on'),
(10, 'use_smilies', '1', 'on'),
(11, 'require_name_email', '1', 'on'),
(12, 'comments_notify', '1', 'on'),
(13, 'posts_per_rss', '10', 'on'),
(14, 'rss_use_excerpt', '0', 'on'),
(15, 'mailserver_url', 'mail.example.com', 'on'),
(16, 'mailserver_login', 'login@example.com', 'on'),
(17, 'mailserver_pass', 'password', 'on'),
(18, 'mailserver_port', '110', 'on'),
(19, 'default_category', '1', 'on'),
(20, 'default_comment_status', 'open', 'on'),
(21, 'default_ping_status', 'open', 'on'),
(22, 'default_pingback_flag', '1', 'on'),
(23, 'posts_per_page', '10', 'on'),
(24, 'date_format', 'F j, Y', 'on'),
(25, 'time_format', 'g:i a', 'on'),
(26, 'links_updated_date_format', 'F j, Y g:i a', 'on'),
(27, 'comment_moderation', '0', 'on'),
(28, 'moderation_notify', '1', 'on'),
(29, 'permalink_structure', '/%post_id%', 'on'),
(30, 'rewrite_rules', 'a:116:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:"subject/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?types=$matches[1]&feed=$matches[2]";s:43:"subject/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?types=$matches[1]&feed=$matches[2]";s:24:"subject/([^/]+)/embed/?$";s:38:"index.php?types=$matches[1]&embed=true";s:36:"subject/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?types=$matches[1]&paged=$matches[2]";s:18:"subject/([^/]+)/?$";s:27:"index.php?types=$matches[1]";s:37:"resources/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"resources/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"resources/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"resources/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"resources/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"resources/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"resources/([^/]+)/embed/?$";s:41:"index.php?resource=$matches[1]&embed=true";s:30:"resources/([^/]+)/trackback/?$";s:35:"index.php?resource=$matches[1]&tb=1";s:38:"resources/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?resource=$matches[1]&paged=$matches[2]";s:45:"resources/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?resource=$matches[1]&cpage=$matches[2]";s:34:"resources/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?resource=$matches[1]&page=$matches[2]";s:26:"resources/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"resources/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"resources/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"resources/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"resources/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"resources/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:74:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:69:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:50:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:62:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:44:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:61:"date/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:56:"date/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:37:"date/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:49:"date/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:31:"date/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:48:"date/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:43:"date/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:24:"date/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:36:"date/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:18:"date/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:28:"[0-9]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"[0-9]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"[0-9]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"[0-9]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"[0-9]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"[0-9]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:17:"([0-9]+)/embed/?$";s:34:"index.php?p=$matches[1]&embed=true";s:21:"([0-9]+)/trackback/?$";s:28:"index.php?p=$matches[1]&tb=1";s:41:"([0-9]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?p=$matches[1]&feed=$matches[2]";s:36:"([0-9]+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?p=$matches[1]&feed=$matches[2]";s:29:"([0-9]+)/page/?([0-9]{1,})/?$";s:41:"index.php?p=$matches[1]&paged=$matches[2]";s:36:"([0-9]+)/comment-page-([0-9]{1,})/?$";s:41:"index.php?p=$matches[1]&cpage=$matches[2]";s:25:"([0-9]+)(?:/([0-9]+))?/?$";s:40:"index.php?p=$matches[1]&page=$matches[2]";s:17:"[0-9]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:27:"[0-9]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:47:"[0-9]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:42:"[0-9]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:42:"[0-9]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:23:"[0-9]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'on'),
(31, 'hack_file', '0', 'on'),
(32, 'blog_charset', 'UTF-8', 'on'),
(33, 'moderation_keys', '', 'off'),
(34, 'active_plugins', 'a:5:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:48:"advanced-custom-fields-table-field/acf-table.php";i:2;s:55:"bluehost-wordpress-plugin/bluehost-wordpress-plugin.php";i:3;s:31:"seo-checklist/seo-checklist.php";i:4;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'on'),
(35, 'category_base', '', 'on'),
(36, 'ping_sites', 'http://rpc.pingomatic.com/', 'on'),
(37, 'comment_max_links', '2', 'on'),
(38, 'gmt_offset', '0', 'on'),
(39, 'default_email_category', '1', 'on'),
(40, 'recently_edited', '', 'off'),
(41, 'template', 'zorvek', 'on'),
(42, 'stylesheet', 'zorvek', 'on'),
(43, 'comment_registration', '0', 'on'),
(44, 'html_type', 'text/html', 'on'),
(45, 'use_trackback', '0', 'on'),
(46, 'default_role', 'subscriber', 'on'),
(47, 'db_version', '57155', 'on'),
(48, 'uploads_use_yearmonth_folders', '1', 'on'),
(49, 'upload_path', '', 'on'),
(50, 'blog_public', '1', 'on'),
(51, 'default_link_category', '0', 'on'),
(52, 'show_on_front', 'page', 'on'),
(53, 'tag_base', '', 'on'),
(54, 'show_avatars', '1', 'on'),
(55, 'avatar_rating', 'G', 'on'),
(56, 'upload_url_path', '', 'on'),
(57, 'thumbnail_size_w', '150', 'on'),
(58, 'thumbnail_size_h', '150', 'on'),
(59, 'thumbnail_crop', '1', 'on'),
(60, 'medium_size_w', '300', 'on'),
(61, 'medium_size_h', '300', 'on'),
(62, 'avatar_default', 'mystery', 'on'),
(63, 'large_size_w', '1024', 'on'),
(64, 'large_size_h', '1024', 'on'),
(65, 'image_default_link_type', 'none', 'on'),
(66, 'image_default_size', '', 'on'),
(67, 'image_default_align', '', 'on'),
(68, 'close_comments_for_old_posts', '0', 'on'),
(69, 'close_comments_days_old', '14', 'on'),
(70, 'thread_comments', '1', 'on'),
(71, 'thread_comments_depth', '5', 'on'),
(72, 'page_comments', '0', 'on'),
(73, 'comments_per_page', '50', 'on'),
(74, 'default_comments_page', 'newest', 'on'),
(75, 'comment_order', 'asc', 'on'),
(76, 'sticky_posts', 'a:0:{}', 'on'),
(77, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(78, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(79, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(80, 'uninstall_plugins', 'a:2:{s:50:"google-analytics-for-wordpress/googleanalytics.php";s:35:"monsterinsights_lite_uninstall_hook";s:37:"optinmonster/optin-monster-wp-api.php";s:32:"optin_monster_api_uninstall_hook";}', 'off'),
(81, 'timezone_string', '', 'on'),
(82, 'page_for_posts', '0', 'on'),
(83, 'page_on_front', '2', 'on'),
(84, 'default_post_format', '0', 'on'),
(85, 'link_manager_enabled', '0', 'on'),
(86, 'finished_splitting_shared_terms', '1', 'on'),
(87, 'site_icon', '0', 'on'),
(88, 'medium_large_size_w', '768', 'on'),
(89, 'medium_large_size_h', '0', 'on'),
(90, 'wp_page_for_privacy_policy', '3', 'on'),
(91, 'show_comments_cookies_opt_in', '1', 'on'),
(92, 'admin_email_lifespan', '1739120696', 'on'),
(93, 'disallowed_keys', '', 'off'),
(94, 'comment_previously_approved', '1', 'on'),
(95, 'auto_plugin_theme_update_emails', 'a:1:{s:34:"advanced-custom-fields-pro/acf.php";s:5:"6.3.6";}', 'off'),
(96, 'auto_update_core_dev', 'enabled', 'on'),
(97, 'auto_update_core_minor', 'enabled', 'on'),
(98, 'auto_update_core_major', 'enabled', 'on'),
(99, 'wp_force_deactivated_plugins', 'a:0:{}', 'on'),
(100, 'wp_attachment_pages_enabled', '0', 'on') ;
INSERT INTO `wper_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'initial_db_version', '57155', 'on'),
(102, 'wper_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'auto'),
(103, 'fresh_site', '0', 'auto'),
(104, 'user_count', '3', 'off'),
(105, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'auto'),
(106, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'auto'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(121, 'recovery_keys', 'a:0:{}', 'auto'),
(122, 'theme_mods_twentytwentyfour', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1723571908;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'off'),
(139, 'nfd_coming_soon_module_version', '1.2.6', 'on'),
(140, 'nfd_coming_soon', '', 'auto'),
(141, 'mm_coming_soon', '', 'auto'),
(142, 'nfd_module_activation_fresh_install', '', 'auto'),
(143, 'ce4wp_hide_banner:get_started', '1', 'auto'),
(144, 'optin_monster_api_activation_redirect_disabled', '1', 'auto'),
(145, 'wpforms_activation_redirect', '1', 'auto'),
(155, 'nfd_data_connection_attempts', '9', 'auto'),
(156, 'newfold_features', 'a:5:{s:8:"patterns";b:1;s:11:"performance";b:1;s:10:"helpCenter";b:1;s:7:"staging";b:1;s:11:"my-products";b:1;}', 'on'),
(157, 'newfold_active_modules', 'a:14:{s:4:"data";b:1;s:9:"installer";b:1;s:2:"ai";b:1;s:11:"coming-soon";b:1;s:16:"wp-module-survey";b:1;s:8:"facebook";b:1;s:9:"migration";b:1;s:9:"ecommerce";b:1;s:10:"global-ctb";b:1;s:11:"marketplace";b:1;s:13:"notifications";b:1;s:10:"onboarding";b:1;s:16:"secure-passwords";b:1;s:3:"sso";b:1;}', 'on'),
(160, 'auto_update_plugins', 'a:7:{i:0;s:48:"advanced-custom-fields-table-field/acf-table.php";i:1;s:34:"advanced-custom-fields-pro/acf.php";i:2;s:19:"akismet/akismet.php";i:3;s:31:"seo-checklist/seo-checklist.php";i:4;s:55:"bluehost-wordpress-plugin/bluehost-wordpress-plugin.php";i:5;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'off'),
(182, 'omapi_review', 'a:2:{s:4:"time";i:1723568715;s:9:"dismissed";b:0;}', 'auto'),
(186, 'widget_optin-monster-api', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(189, 'action_scheduler_hybrid_store_demarkation', '5', 'auto'),
(190, 'schema-ActionScheduler_StoreSchema', '7.0.1723568721', 'auto'),
(191, 'schema-ActionScheduler_LoggerSchema', '3.0.1723568721', 'auto'),
(194, 'wpforms_version', '1.9.0.2', 'auto'),
(195, 'wpforms_version_lite', '1.9.0.2', 'auto'),
(196, 'wpforms_activated', 'a:1:{s:4:"lite";i:1723568721;}', 'auto'),
(203, 'wpforms_versions_lite', 'a:12:{s:5:"1.5.9";i:0;s:7:"1.6.7.2";i:0;s:5:"1.6.8";i:0;s:5:"1.7.5";i:0;s:7:"1.7.5.1";i:0;s:5:"1.7.7";i:0;s:5:"1.8.2";i:0;s:5:"1.8.3";i:0;s:5:"1.8.4";i:0;s:5:"1.8.6";i:0;s:5:"1.8.7";i:0;s:7:"1.9.0.2";i:1723568724;}', 'auto'),
(204, 'widget_wpforms-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(205, 'wpforms_settings', 'a:3:{s:13:"modern-markup";s:1:"1";s:20:"modern-markup-is-set";b:1;s:26:"modern-markup-hide-setting";b:1;}', 'auto'),
(207, 'jetpack_connection_active_plugins', 'a:1:{s:7:"jetpack";a:1:{s:4:"name";s:7:"Jetpack";}}', 'auto'),
(210, 'om_notifications', 'a:4:{s:7:"updated";i:1723568725;s:4:"feed";a:0:{}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}}', 'off'),
(211, 'optinmonster_upgrade_completed', '2.16.4', 'auto'),
(213, 'nfd_data_module_version', '2.6.3', 'on'),
(214, 'nfd_ecommerce_module_version', '1.3.43', 'on'),
(215, 'jetpack_affiliate_code', '86241', 'auto'),
(216, 'auto_update_themes', 'a:4:{i:0;s:7:"sinatra";i:1;s:16:"twentytwentyfour";i:2;s:17:"twentytwentythree";i:3;s:15:"twentytwentytwo";}', 'off'),
(217, 'bluehost_plugin_version', '3.14.9', 'on'),
(220, 'mm_install_date', 'Aug 13, 2024', 'auto'),
(221, 'mm_cron', 'a:1:{s:6:"hourly";a:1:{s:9:"installed";a:5:{s:1:"t";s:5:"event";s:2:"ec";s:13:"plugin_status";s:2:"ea";s:9:"installed";s:2:"el";s:26:"Install date: Aug 13, 2024";s:4:"keep";b:0;}}}', 'auto'),
(222, 'bluehost_plugin_install_date', '1723568743', 'on'),
(223, 'do_activate', '0', 'auto'),
(224, 'jetpack_waf_needs_update', '', 'auto'),
(225, 'action_scheduler_lock_async-request-runner', '66bb92b7d45e29.75294553|1723568883', 'no'),
(235, 'finished_updating_comment_type', '1', 'auto'),
(247, 'wpforms_admin_notices', 'a:1:{s:14:"review_request";a:2:{s:4:"time";i:1723568826;s:9:"dismissed";b:0;}}', 'auto'),
(248, 'nfd_module_survey_queue', 'a:0:{}', 'auto'),
(249, 'nfd_module_onboarding_flow', 'a:20:{s:7:"version";s:5:"2.0.6";s:8:"isViewed";a:0:{}s:10:"isComplete";i:0;s:9:"hasExited";i:0;s:9:"isSkipped";a:0:{}s:11:"currentStep";s:26:"/step/wp-setup/get-started";s:9:"createdAt";i:1723568826;s:9:"updatedAt";i:0;s:4:"data";a:18:{s:8:"siteType";a:3:{s:7:"referTo";s:4:"site";s:7:"primary";a:2:{s:6:"refers";s:0:"";s:5:"value";s:0:"";}s:9:"secondary";a:2:{s:6:"refers";s:0:"";s:5:"value";s:0:"";}}s:14:"wpComfortLevel";s:1:"0";s:11:"topPriority";a:1:{s:9:"priority1";s:0:"";}s:8:"blogName";s:0:"";s:15:"blogDescription";s:0:"";s:8:"siteLogo";a:2:{s:2:"id";i:0;s:3:"url";s:0:"";}s:8:"accounts";a:0:{}s:5:"theme";a:3:{s:8:"template";s:0:"";s:10:"stylesheet";s:0:"";s:9:"variation";s:0:"";}s:12:"customDesign";b:0;s:10:"colorStyle";s:0:"";s:9:"fontStyle";s:0:"";s:10:"partHeader";s:0:"";s:10:"partFooter";s:0:"";s:9:"sitePages";a:2:{s:8:"homepage";s:0:"";s:5:"other";a:0:{}}s:12:"siteFeatures";a:0:{}s:8:"chapters";a:0:{}s:10:"comingSoon";b:0;s:19:"siteOverrideConsent";b:0;}s:10:"activeFlow";s:0:"";s:12:"currentFlows";a:0:{}s:20:"isFirstNFDOnboarding";b:1;s:8:"siteType";s:4:"blog";s:9:"ownerType";s:8:"personal";s:15:"isEcommercePlan";b:0;s:12:"doesCommerce";b:0;s:12:"storeDetails";a:1:{s:11:"productInfo";a:2:{s:13:"product_count";s:0:"";s:13:"product_types";a:0:{}}}s:7:"sitegen";a:9:{s:11:"siteDetails";a:7:{s:4:"name";s:0:"";s:4:"type";s:0:"";s:5:"style";s:0:"";s:6:"prompt";s:0:"";s:19:"uniqueAboutBusiness";s:0:"";s:12:"minCharLimit";i:34;s:4:"mode";s:6:"simple";}s:8:"siteLogo";a:4:{s:2:"id";i:0;s:3:"url";s:0:"";s:8:"fileName";s:0:"";s:8:"fileSize";i:0;}s:10:"experience";a:1:{s:5:"level";i:0;}s:17:"siteGenMetaStatus";a:2:{s:13:"currentStatus";i:0;s:10:"totalCount";i:9;}s:9:"homepages";a:2:{s:6:"active";a:0:{}s:4:"data";a:0:{}}s:9:"skipCache";b:1;s:21:"sitemapPagesGenerated";b:0;s:12:"customDesign";b:0;s:16:"siteGenErrorMeta";a:3:{s:6:"status";b:0;s:10:"retryCount";i:0;s:13:"maxRetryCount";i:3;}}s:17:"continueWithoutAi";b:0;s:16:"sitegenThemeMode";s:0:"";}', 'auto'),
(253, 'nfd_module_installer_plugin_install_queue', 'a:0:{}', 'auto'),
(254, 'nfd_module_installer_plugin_activation_queue', 'a:0:{}', 'auto'),
(255, 'nfd_module_installer_plugins_init_status', 'completed', 'auto'),
(256, 'yoast_migrations_free', 'a:1:{s:7:"version";s:4:"23.2";}', 'auto'),
(257, 'nfd_module_installer_plugin_deactivation_queue', 'a:0:{}', 'auto'),
(260, 'can_compress_scripts', '0', 'on'),
(264, 'ce4wp_ignore_review_notice', '1', 'auto'),
(265, 'onboarding_experience_level', '0', 'auto'),
(266, 'wpseo', 'a:108:{s:8:"tracking";b:0;s:16:"toggled_tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:0;s:40:"ignore_search_engines_discouraged_notice";b:0;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:26:"permalink_settings_changed";s:29:"indexables_indexing_completed";b:0;s:13:"index_now_key";s:0:"";s:7:"version";s:4:"23.2";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:0;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:34:"inclusive_language_analysis_active";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:16:"enable_index_now";b:1;s:19:"enable_ai_generator";b:1;s:22:"ai_enabled_pre_default";b:0;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1723568832;s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:36:"/%year%/%monthnum%/%day%/%postname%/";s:8:"home_url";s:22:"http://localhost:10004";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:0:"";s:12:"tag_base_url";s:0:"";s:21:"custom_taxonomy_slugs";a:0:{}s:29:"enable_enhanced_slack_sharing";b:1;s:25:"zapier_integration_active";b:0;s:19:"zapier_subscription";a:0:{}s:14:"zapier_api_key";s:0:"";s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:28:"configuration_finished_steps";a:0:{}s:36:"dismiss_configuration_workout_notice";b:1;s:34:"dismiss_premium_deactivated_notice";b:0;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:1;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:18:"first_time_install";b:1;s:34:"should_redirect_after_install_free";b:0;s:34:"activation_redirect_timestamp_free";b:0;s:18:"remove_feed_global";b:0;s:27:"remove_feed_global_comments";b:0;s:25:"remove_feed_post_comments";b:0;s:19:"remove_feed_authors";b:0;s:22:"remove_feed_categories";b:0;s:16:"remove_feed_tags";b:0;s:29:"remove_feed_custom_taxonomies";b:0;s:22:"remove_feed_post_types";b:0;s:18:"remove_feed_search";b:0;s:21:"remove_atom_rdf_feeds";b:0;s:17:"remove_shortlinks";b:0;s:21:"remove_rest_api_links";b:0;s:20:"remove_rsd_wlw_links";b:0;s:19:"remove_oembed_links";b:0;s:16:"remove_generator";b:0;s:20:"remove_emoji_scripts";b:0;s:24:"remove_powered_by_header";b:0;s:22:"remove_pingback_header";b:0;s:28:"clean_campaign_tracking_urls";b:0;s:16:"clean_permalinks";b:0;s:32:"clean_permalinks_extra_variables";s:0:"";s:14:"search_cleanup";b:0;s:20:"search_cleanup_emoji";b:0;s:23:"search_cleanup_patterns";b:0;s:22:"search_character_limit";i:50;s:20:"deny_search_crawling";b:0;s:21:"deny_wp_json_crawling";b:0;s:20:"deny_adsbot_crawling";b:0;s:19:"deny_ccbot_crawling";b:0;s:29:"deny_google_extended_crawling";b:0;s:20:"deny_gptbot_crawling";b:0;s:27:"redirect_search_pretty_urls";b:0;s:29:"least_readability_ignore_list";a:0:{}s:27:"least_seo_score_ignore_list";a:0:{}s:23:"most_linked_ignore_list";a:0:{}s:24:"least_linked_ignore_list";a:0:{}s:28:"indexables_page_reading_list";a:5:{i:0;b:0;i:1;b:0;i:2;b:0;i:3;b:0;i:4;b:0;}s:25:"indexables_overview_state";s:21:"dashboard-not-visited";s:28:"last_known_public_post_types";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:28:"last_known_public_taxonomies";a:3:{i:0;s:8:"category";i:1;s:8:"post_tag";i:2;s:11:"post_format";}s:23:"last_known_no_unindexed";a:1:{s:40:"wpseo_total_unindexed_post_type_archives";i:1723568835;}s:14:"new_post_types";a:0:{}s:14:"new_taxonomies";a:0:{}s:34:"show_new_content_type_notification";b:0;}', 'auto'),
(267, 'wpseo_titles', 'a:129:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:2:"»";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:22:"company_alternate_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:12:"%%sitename%%";s:25:"open_graph_frontpage_desc";s:0:"";s:26:"open_graph_frontpage_image";s:0:"";s:24:"publishing_principles_id";i:0;s:25:"ownership_funding_info_id";i:0;s:29:"actionable_feedback_policy_id";i:0;s:21:"corrections_policy_id";i:0;s:16:"ethics_policy_id";i:0;s:19:"diversity_policy_id";i:0;s:28:"diversity_staffing_report_id";i:0;s:15:"org-description";s:0:"";s:9:"org-email";s:0:"";s:9:"org-phone";s:0:"";s:14:"org-legal-name";s:0:"";s:17:"org-founding-date";s:0:"";s:20:"org-number-employees";s:0:"";s:10:"org-vat-id";s:0:"";s:10:"org-tax-id";s:0:"";s:7:"org-iso";s:0:"";s:8:"org-duns";s:0:"";s:11:"org-leicode";s:0:"";s:9:"org-naics";s:0:"";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:23:"%%term_title%% Archives";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:26:"taxonomy-category-ptparent";i:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:23:"%%term_title%% Archives";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:26:"taxonomy-post_tag-ptparent";i:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:23:"%%term_title%% Archives";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:29:"taxonomy-post_format-ptparent";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:0;s:17:"company_logo_meta";b:0;s:16:"person_logo_meta";b:0;s:29:"open_graph_frontpage_image_id";i:0;}', 'auto'),
(268, 'wpseo_social', 'a:20:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:17:"other_social_urls";a:0:{}s:12:"mastodon_url";s:0:"";}', 'auto'),
(276, '_wpforms_transient_timeout_addons.json', '1724173635', 'off'),
(277, '_wpforms_transient_addons.json', '1723568835', 'off'),
(294, 'recently_activated', 'a:1:{s:31:"wp-migrate-db/wp-migrate-db.php";i:1726623774;}', 'auto'),
(330, 'ce4wp_activation_redirect', '', 'auto'),
(333, 'ce4wp_handshake_token', '21D422E0-7995-4AE4-A552-925FB216E00C', 'auto'),
(334, 'ce4wp_handshake_expiration', '1723572617', 'auto'),
(335, 'ce4wp_instance_uuid', '66bb9379ce910', 'auto'),
(337, 'ce4wp_contacts_db_version', '1.0', 'auto'),
(342, 'widget_monsterinsights-popular-posts-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(344, 'monsterinsights_settings', 'a:45:{s:22:"enable_affiliate_links";b:1;s:15:"affiliate_links";a:2:{i:0;a:2:{s:4:"path";s:4:"/go/";s:5:"label";s:9:"affiliate";}i:1;a:2:{s:4:"path";s:11:"/recommend/";s:5:"label";s:9:"affiliate";}}s:12:"demographics";i:1;s:12:"ignore_users";a:2:{i:0;s:13:"administrator";i:1;s:6:"editor";}s:19:"dashboards_disabled";i:0;s:13:"anonymize_ips";i:0;s:19:"extensions_of_files";s:34:"doc,pdf,ppt,zip,xls,docx,pptx,xlsx";s:18:"subdomain_tracking";s:0:"";s:16:"link_attribution";b:1;s:16:"tag_links_in_rss";b:1;s:12:"allow_anchor";i:0;s:16:"add_allow_linker";i:0;s:13:"save_settings";a:1:{i:0;s:13:"administrator";}s:12:"view_reports";a:2:{i:0;s:13:"administrator";i:1;s:6:"editor";}s:11:"events_mode";s:2:"js";s:13:"tracking_mode";s:4:"gtag";s:15:"email_summaries";s:2:"on";s:23:"summaries_html_template";s:3:"yes";s:25:"summaries_email_addresses";a:1:{i:0;a:1:{s:5:"email";s:27:"admin@ehy.sgz.mybluehost.me";}}s:31:"exception_alert_email_addresses";a:1:{i:0;a:1:{s:5:"email";s:27:"admin@ehy.sgz.mybluehost.me";}}s:17:"automatic_updates";s:3:"all";s:14:"anonymous_data";i:0;s:18:"verified_automatic";i:0;s:26:"popular_posts_inline_theme";s:5:"alpha";s:26:"popular_posts_widget_theme";s:5:"alpha";s:28:"popular_posts_products_theme";s:5:"alpha";s:30:"popular_posts_inline_placement";s:6:"manual";s:34:"popular_posts_widget_theme_columns";s:1:"2";s:36:"popular_posts_products_theme_columns";s:1:"2";s:26:"popular_posts_widget_count";s:1:"4";s:28:"popular_posts_products_count";s:1:"4";s:38:"popular_posts_widget_theme_meta_author";s:2:"on";s:36:"popular_posts_widget_theme_meta_date";s:2:"on";s:40:"popular_posts_widget_theme_meta_comments";s:2:"on";s:39:"popular_posts_products_theme_meta_price";s:2:"on";s:40:"popular_posts_products_theme_meta_rating";s:2:"on";s:39:"popular_posts_products_theme_meta_image";s:2:"on";s:32:"popular_posts_inline_after_count";s:3:"150";s:36:"popular_posts_inline_multiple_number";s:1:"3";s:38:"popular_posts_inline_multiple_distance";s:3:"250";s:39:"popular_posts_inline_multiple_min_words";s:3:"100";s:31:"popular_posts_inline_post_types";a:1:{i:0;s:4:"post";}s:31:"popular_posts_widget_post_types";a:1:{i:0;s:4:"post";}s:19:"verified_appearance";s:5:"light";s:17:"verified_position";s:6:"center";}', 'auto'),
(345, 'monsterinsights_over_time', 'a:4:{s:17:"installed_version";s:5:"9.0.0";s:14:"installed_date";i:1723569139;s:13:"installed_pro";b:0;s:14:"installed_lite";i:1723569139;}', 'off'),
(347, 'monsterinsights_current_version', '9.0.0', 'auto'),
(349, 'monsterinsights_sitenotes_installed', '1723569139', 'auto'),
(350, 'monsterinsights_feedback_tracked_features', 'a:0:{}', 'auto'),
(390, 'deleted_plugin', 'a:7:{s:4:"slug";s:33:"classic-editor/classic-editor.php";s:7:"version";s:5:"1.6.4";s:5:"title";s:14:"Classic Editor";s:3:"url";s:45:"https://wordpress.org/plugins/classic-editor/";s:6:"active";b:0;s:2:"mu";b:0;s:12:"auto_updates";b:1;}', 'auto'),
(399, 'acf_first_activated_version', '6.3.4', 'on'),
(400, 'acf_site_health', '{"version":"6.3.4","plugin_type":"PRO","activated":true,"activated_url":"https:\\/\\/ehy.sgz.mybluehost.local","license_type":"Agency","license_status":"active","subscription_expires":"","wp_version":"6.6.1","mysql_version":"5.7.28","is_multisite":false,"active_theme":{"name":"Zorvek","version":"1.5","theme_uri":"","stylesheet":false},"active_plugins":{"advanced-custom-fields-table-field\\/acf-table.php":{"name":"Advanced Custom Fields: Table Field","version":"1.3.24","plugin_uri":"http:\\/\\/www.johannheyne.de\\/"},"advanced-custom-fields-pro\\/acf.php":{"name":"Advanced Custom Fields PRO","version":"6.3.4","plugin_uri":"https:\\/\\/www.advancedcustomfields.com"},"seo-checklist\\/seo-checklist.php":{"name":"SEO Checklist","version":"1.0","plugin_uri":""},"bluehost-wordpress-plugin\\/bluehost-wordpress-plugin.php":{"name":"The Bluehost Plugin","version":"3.14.9","plugin_uri":"https:\\/\\/bluehost.com"},"wp-migrate-db\\/wp-migrate-db.php":{"name":"WP Migrate Lite","version":"2.6.11","plugin_uri":"https:\\/\\/wordpress.org\\/plugins\\/wp-migrate-db\\/"}},"ui_field_groups":"5","php_field_groups":"0","json_field_groups":"0","rest_field_groups":"0","number_of_fields_by_type":{"select":1,"taxonomy":2,"flexible_content":3,"textarea":1,"repeater":1},"number_of_third_party_fields_by_type":[],"post_types_enabled":true,"ui_post_types":"4","json_post_types":"0","ui_taxonomies":"4","json_taxonomies":"0","ui_options_pages_enabled":true,"ui_options_pages":"0","json_options_pages":"0","php_options_pages":"0","rest_api_format":"light","registered_acf_blocks":"0","blocks_per_api_version":[],"blocks_per_acf_block_version":[],"blocks_using_post_meta":"0","preload_blocks":true,"admin_ui_enabled":true,"field_type-modal_enabled":true,"field_settings_tabs_enabled":false,"shortcode_enabled":false,"registered_acf_forms":"0","json_save_paths":1,"json_load_paths":1,"event_first_activated_pro":1723571832,"event_first_created_field_group":1723572073,"last_updated":1726607735}', 'off'),
(402, 'acf_version', '6.3.4', 'auto'),
(407, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czozMjoiQjVFMEI1RjhERDg2ODlFNkFDQTQ5REQ2RTZFMUE5MzAiO3M6MzoidXJsIjtzOjMyOiJodHRwczovL2VoeS5zZ3oubXlibHVlaG9zdC5sb2NhbCI7fQ==', 'off'),
(456, 'current_theme', 'Zorvek', 'auto'),
(457, 'theme_mods_zorvek', 'a:4:{i:0;b:0;s:19:"wp_classic_sidebars";a:0:{}s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'on'),
(458, 'theme_switched', '', 'auto'),
(486, 'nfd_fb_hash_hiive_token', '4f3c52fe9940d74e329eabe7ab8b36bd', 'auto'),
(487, 'nfd_coming_soon_last_changed', '1723572942', 'auto'),
(494, 'WPLANG', '', 'auto'),
(495, 'new_admin_email', 'admin@ehy.sgz.mybluehost.me', 'auto'),
(496, 'epc_skip_404_handling', '', 'auto') ;
INSERT INTO `wper_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(497, 'newfold_cache_level', '0', 'auto'),
(498, 'mm_cache_settings', 'a:2:{s:4:"page";s:8:"disabled";s:7:"browser";s:8:"disabled";}', 'auto'),
(3069, 'classic-editor-replace', 'block', 'auto'),
(3070, 'classic-editor-allow-users', 'allow', 'auto'),
(3462, 'category_children', 'a:0:{}', 'auto'),
(3468, 'recovery_mode_email_last_sent', '1724867770', 'auto'),
(3938, 'types_children', 'a:0:{}', 'auto'),
(4730, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1726625587;}', 'off'),
(4762, 'acf_pro_license_status', 'a:10:{s:6:"status";s:6:"active";s:7:"created";i:0;s:6:"expiry";i:0;s:4:"name";s:6:"Agency";s:8:"lifetime";b:1;s:8:"refunded";b:0;s:17:"view_licenses_url";s:62:"https://www.advancedcustomfields.com/my-account/view-licenses/";s:23:"manage_subscription_url";s:0:"";s:9:"error_msg";s:0:"";s:10:"next_check";i:1727021956;}', 'on'),
(4937, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:27:"admin@ehy.sgz.mybluehost.me";s:7:"version";s:5:"6.6.2";s:9:"timestamp";i:1726607735;}', 'off'),
(4938, 'nfd_module_onboarding_compatibility_results', 'a:2:{s:6:"status";s:10:"compatible";s:9:"timestamp";s:19:"2024-09-17 22:16:46";}', 'auto'),
(4958, 'wp_migrate_addon_schema', '1', 'auto') ;

#
# End of data contents of table `wper_options`
# --------------------------------------------------------



#
# Delete any existing table `wper_postmeta`
#

DROP TABLE IF EXISTS `wper_postmeta`;


#
# Table structure of table `wper_postmeta`
#

CREATE TABLE `wper_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1066 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_postmeta`
#
INSERT INTO `wper_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'templates/template-flexible.php'),
(2, 3, '_wp_page_template', 'default'),
(5, 2, '_edit_lock', '1724878928:2'),
(6, 2, '_edit_last', '2'),
(7, 9, '_edit_last', '2'),
(8, 9, '_edit_lock', '1724712430:2'),
(9, 2, 'flexible_template_0_headline', 'Unlock the <strong>power</strong> of your data'),
(10, 2, '_flexible_template_0_headline', 'field_66bb9f31e6ce1'),
(11, 2, 'flexible_template_0_subline', 'Transform <a href="/tools/">excel challenges into solutions</a> with expert automation'),
(12, 2, '_flexible_template_0_subline', 'field_66bb9f58e6ce2'),
(13, 2, 'flexible_template', 'a:1:{i:0;s:4:"hero";}'),
(14, 2, '_flexible_template', 'field_66bb9f06e6ce0'),
(21, 14, '_edit_lock', '1725067954:2'),
(22, 14, '_edit_last', '2'),
(23, 18, '_wp_attached_file', '2024/08/dog-typing.jpeg'),
(24, 18, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:620;s:6:"height";i:330;s:4:"file";s:23:"2024/08/dog-typing.jpeg";s:8:"filesize";i:31885;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:23:"dog-typing-300x160.jpeg";s:5:"width";i:300;s:6:"height";i:160;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10519;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"dog-typing-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5571;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(25, 14, '_thumbnail_id', '18'),
(26, 2, 'flexible_template_0_cta', ''),
(27, 2, '_flexible_template_0_cta', 'field_66c3d5c929e86'),
(28, 2, 'flexible_template_0_extra_cta', ''),
(29, 2, '_flexible_template_0_extra_cta', 'field_66c3d5e429e87'),
(30, 2, 'flexible_template_0_image_type', 'full'),
(31, 2, '_flexible_template_0_image_type', 'field_66c3d6b4089d8'),
(32, 2, 'flexible_template_0_bg_img', ''),
(33, 2, '_flexible_template_0_bg_img', 'field_66c3d6df089d9'),
(66, 30, 'flexible_template_0_headline', 'Unlock the <strong>power</strong> of your data'),
(67, 30, '_flexible_template_0_headline', 'field_66bb9f31e6ce1'),
(68, 30, 'flexible_template_0_subline', 'Transform excel challenges into solutions with expert automation'),
(69, 30, '_flexible_template_0_subline', 'field_66bb9f58e6ce2'),
(70, 30, 'flexible_template', 'a:1:{i:0;s:4:"hero";}'),
(71, 30, '_flexible_template', 'field_66bb9f06e6ce0'),
(72, 30, 'flexible_template_0_cta', ''),
(73, 30, '_flexible_template_0_cta', 'field_66c3d5c929e86'),
(74, 30, 'flexible_template_0_extra_cta', ''),
(75, 30, '_flexible_template_0_extra_cta', 'field_66c3d5e429e87'),
(76, 30, 'flexible_template_0_image_type', 'full'),
(77, 30, '_flexible_template_0_image_type', 'field_66c3d6b4089d8'),
(78, 30, 'flexible_template_0_bg_img', ''),
(79, 30, '_flexible_template_0_bg_img', 'field_66c3d6df089d9'),
(80, 31, '_edit_lock', '1724433269:2'),
(81, 31, '_edit_last', '2'),
(82, 32, '_wp_attached_file', '2024/08/2c87f3bbcc1aa9a14b2dcc927aabd785.jpg'),
(83, 32, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:563;s:6:"height";i:742;s:4:"file";s:44:"2024/08/2c87f3bbcc1aa9a14b2dcc927aabd785.jpg";s:8:"filesize";i:55294;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:44:"2c87f3bbcc1aa9a14b2dcc927aabd785-228x300.jpg";s:5:"width";i:228;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10741;}s:9:"thumbnail";a:5:{s:4:"file";s:44:"2c87f3bbcc1aa9a14b2dcc927aabd785-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4265;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(84, 33, '_wp_attached_file', '2024/08/40650c5a6506cfe1b804176a8be72d0f.jpg'),
(85, 33, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:564;s:6:"height";i:513;s:4:"file";s:44:"2024/08/40650c5a6506cfe1b804176a8be72d0f.jpg";s:8:"filesize";i:30465;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:44:"40650c5a6506cfe1b804176a8be72d0f-300x273.jpg";s:5:"width";i:300;s:6:"height";i:273;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13046;}s:9:"thumbnail";a:5:{s:4:"file";s:44:"40650c5a6506cfe1b804176a8be72d0f-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5808;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(86, 34, '_wp_attached_file', '2024/08/shormp.jpg'),
(87, 34, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:514;s:6:"height";i:514;s:4:"file";s:18:"2024/08/shormp.jpg";s:8:"filesize";i:35388;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:18:"shormp-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10669;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"shormp-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6494;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(88, 35, '_wp_attached_file', '2024/08/oh-shit.jpg'),
(89, 35, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:19:"2024/08/oh-shit.jpg";s:8:"filesize";i:14239;s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:19:"oh-shit-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4803;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(90, 36, '_wp_attached_file', '2024/08/gasp.jpeg'),
(91, 36, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:563;s:6:"height";i:428;s:4:"file";s:17:"2024/08/gasp.jpeg";s:8:"filesize";i:15794;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:17:"gasp-300x228.jpeg";s:5:"width";i:300;s:6:"height";i:228;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6648;}s:9:"thumbnail";a:5:{s:4:"file";s:17:"gasp-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3447;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(92, 37, '_wp_attached_file', '2024/08/dont-with-me.jpeg'),
(93, 37, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:564;s:6:"height";i:716;s:4:"file";s:25:"2024/08/dont-with-me.jpeg";s:8:"filesize";i:39251;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:25:"dont-with-me-236x300.jpeg";s:5:"width";i:236;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11708;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"dont-with-me-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5186;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(94, 31, '_wp_page_template', 'templates/template-flexible.php'),
(95, 31, 'flexible_template_0_headline', 'Beep'),
(96, 31, '_flexible_template_0_headline', 'field_66bb9f31e6ce1'),
(97, 31, 'flexible_template_0_subline', 'Boop'),
(98, 31, '_flexible_template_0_subline', 'field_66bb9f58e6ce2'),
(99, 31, 'flexible_template_0_cta', ''),
(100, 31, '_flexible_template_0_cta', 'field_66c3d5c929e86'),
(101, 31, 'flexible_template_0_extra_cta', ''),
(102, 31, '_flexible_template_0_extra_cta', 'field_66c3d5e429e87'),
(103, 31, 'flexible_template_0_image_type', 'multiple'),
(104, 31, '_flexible_template_0_image_type', 'field_66c3d6b4089d8'),
(105, 31, 'flexible_template_0_images', 'a:3:{i:0;s:2:"34";i:1;s:2:"35";i:2;s:2:"36";}'),
(106, 31, '_flexible_template_0_images', 'field_66c3d6fa089da'),
(107, 31, 'flexible_template', 'a:1:{i:0;s:4:"hero";}'),
(108, 31, '_flexible_template', 'field_66bb9f06e6ce0'),
(109, 38, 'flexible_template_0_headline', 'Beep'),
(110, 38, '_flexible_template_0_headline', 'field_66bb9f31e6ce1'),
(111, 38, 'flexible_template_0_subline', 'Boop'),
(112, 38, '_flexible_template_0_subline', 'field_66bb9f58e6ce2'),
(113, 38, 'flexible_template_0_cta', ''),
(114, 38, '_flexible_template_0_cta', 'field_66c3d5c929e86'),
(115, 38, 'flexible_template_0_extra_cta', ''),
(116, 38, '_flexible_template_0_extra_cta', 'field_66c3d5e429e87'),
(117, 38, 'flexible_template_0_image_type', 'multiple'),
(118, 38, '_flexible_template_0_image_type', 'field_66c3d6b4089d8'),
(119, 38, 'flexible_template_0_images', 'a:3:{i:0;s:2:"34";i:1;s:2:"35";i:2;s:2:"36";}'),
(120, 38, '_flexible_template_0_images', 'field_66c3d6fa089da'),
(121, 38, 'flexible_template', 'a:1:{i:0;s:4:"hero";}'),
(122, 38, '_flexible_template', 'field_66bb9f06e6ce0'),
(123, 39, '_edit_lock', '1724989911:2'),
(124, 39, '_edit_last', '2'),
(125, 46, '_edit_lock', '1724881571:2'),
(126, 46, '_edit_last', '2'),
(128, 14, 'meta_desc', 'Master VBA conditional compilation to manage code across Office versions, bit environments, and debugging modes.'),
(129, 14, '_meta_desc', 'field_66c785b395997'),
(130, 14, 'keywords', '4'),
(131, 14, '_keywords', 'field_66c7860695998'),
(132, 14, 'flexible_resource', 'a:3:{i:0;s:7:"wysiwyg";i:1;s:12:"code_snippet";i:2;s:7:"wysiwyg";}'),
(133, 14, '_flexible_resource', 'field_66c783567bf00'),
(138, 2, 'meta_desc', 'fjkdlsjfklsdj flkjsd lfkjsd lfksjd flskdj flsdk fjlsdk ffj dklsj fkldsj klfjs dkljfkldsj lkfj jfklds jflkds jfkldsfj dklsj dksfdkfs dkljdklsj dklfjs dklfjdl'),
(139, 2, '_meta_desc', 'field_66c785b395997'),
(140, 2, 'keywords', '4'),
(141, 2, '_keywords', 'field_66c7860695998'),
(142, 2, 'keywords_0_keyword', 'fdsfs'),
(143, 2, '_keywords_0_keyword', 'field_66c7862d95999'),
(144, 2, 'keywords_1_keyword', 'fsdfds'),
(145, 2, '_keywords_1_keyword', 'field_66c7862d95999') ;
INSERT INTO `wper_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(146, 2, 'keywords_2_keyword', 'sdfdsfs'),
(147, 2, '_keywords_2_keyword', 'field_66c7862d95999'),
(148, 51, 'flexible_template_0_headline', 'Unlock the <strong>power</strong> of your data'),
(149, 51, '_flexible_template_0_headline', 'field_66bb9f31e6ce1'),
(150, 51, 'flexible_template_0_subline', 'Transform excel challenges into solutions with expert automation'),
(151, 51, '_flexible_template_0_subline', 'field_66bb9f58e6ce2'),
(152, 51, 'flexible_template', 'a:1:{i:0;s:4:"hero";}'),
(153, 51, '_flexible_template', 'field_66bb9f06e6ce0'),
(154, 51, 'flexible_template_0_cta', ''),
(155, 51, '_flexible_template_0_cta', 'field_66c3d5c929e86'),
(156, 51, 'flexible_template_0_extra_cta', ''),
(157, 51, '_flexible_template_0_extra_cta', 'field_66c3d5e429e87'),
(158, 51, 'flexible_template_0_image_type', 'full'),
(159, 51, '_flexible_template_0_image_type', 'field_66c3d6b4089d8'),
(160, 51, 'flexible_template_0_bg_img', ''),
(161, 51, '_flexible_template_0_bg_img', 'field_66c3d6df089d9'),
(162, 51, 'meta_desc', 'fjkdlsjfklsdj flkjsd lfkjsd lfksjd flskdj flsdk fjlsdk fjlsdk fjsldkf jsdlkf jsdlfk jldsk fjldsk fjdsk fjlsdfk jlksdjf ldksfjl dksfjdks fjlsdkfj ldksf s'),
(163, 51, '_meta_desc', 'field_66c785b395997'),
(164, 51, 'keywords', '3'),
(165, 51, '_keywords', 'field_66c7860695998'),
(166, 51, 'keywords_0_keyword', 'fdsfs'),
(167, 51, '_keywords_0_keyword', 'field_66c7862d95999'),
(168, 51, 'keywords_1_keyword', 'fsdfds'),
(169, 51, '_keywords_1_keyword', 'field_66c7862d95999'),
(170, 51, 'keywords_2_keyword', 'sdfdsfs'),
(171, 51, '_keywords_2_keyword', 'field_66c7862d95999'),
(172, 2, 'keywords_3_keyword', 'fdsfsd'),
(173, 2, '_keywords_3_keyword', 'field_66c7862d95999'),
(174, 52, 'flexible_template_0_headline', 'Unlock the <strong>power</strong> of your data'),
(175, 52, '_flexible_template_0_headline', 'field_66bb9f31e6ce1'),
(176, 52, 'flexible_template_0_subline', 'Transform excel challenges into solutions with expert automation'),
(177, 52, '_flexible_template_0_subline', 'field_66bb9f58e6ce2'),
(178, 52, 'flexible_template', 'a:1:{i:0;s:4:"hero";}'),
(179, 52, '_flexible_template', 'field_66bb9f06e6ce0'),
(180, 52, 'flexible_template_0_cta', ''),
(181, 52, '_flexible_template_0_cta', 'field_66c3d5c929e86'),
(182, 52, 'flexible_template_0_extra_cta', ''),
(183, 52, '_flexible_template_0_extra_cta', 'field_66c3d5e429e87'),
(184, 52, 'flexible_template_0_image_type', 'full'),
(185, 52, '_flexible_template_0_image_type', 'field_66c3d6b4089d8'),
(186, 52, 'flexible_template_0_bg_img', ''),
(187, 52, '_flexible_template_0_bg_img', 'field_66c3d6df089d9'),
(188, 52, 'meta_desc', 'fjkdlsjfklsdj flkjsd lfkjsd lfksjd flskdj flsdk fjlsdk fjlsdk fjsldkf jsdlkf jsdlfk jldsk fjldsk fjdsk fjlsdfk jlksdjf ldksfjl dksfjdks fjlsdkfj ldksf sfds'),
(189, 52, '_meta_desc', 'field_66c785b395997'),
(190, 52, 'keywords', '4'),
(191, 52, '_keywords', 'field_66c7860695998'),
(192, 52, 'keywords_0_keyword', 'fdsfs'),
(193, 52, '_keywords_0_keyword', 'field_66c7862d95999'),
(194, 52, 'keywords_1_keyword', 'fsdfds'),
(195, 52, '_keywords_1_keyword', 'field_66c7862d95999'),
(196, 52, 'keywords_2_keyword', 'sdfdsfs'),
(197, 52, '_keywords_2_keyword', 'field_66c7862d95999'),
(198, 52, 'keywords_3_keyword', 'fdsfsd'),
(199, 52, '_keywords_3_keyword', 'field_66c7862d95999'),
(200, 53, 'flexible_template_0_headline', 'Unlock the <strong>power</strong> of your data'),
(201, 53, '_flexible_template_0_headline', 'field_66bb9f31e6ce1'),
(202, 53, 'flexible_template_0_subline', 'Transform excel challenges into solutions with expert automation'),
(203, 53, '_flexible_template_0_subline', 'field_66bb9f58e6ce2'),
(204, 53, 'flexible_template', 'a:1:{i:0;s:4:"hero";}'),
(205, 53, '_flexible_template', 'field_66bb9f06e6ce0'),
(206, 53, 'flexible_template_0_cta', ''),
(207, 53, '_flexible_template_0_cta', 'field_66c3d5c929e86'),
(208, 53, 'flexible_template_0_extra_cta', ''),
(209, 53, '_flexible_template_0_extra_cta', 'field_66c3d5e429e87'),
(210, 53, 'flexible_template_0_image_type', 'full'),
(211, 53, '_flexible_template_0_image_type', 'field_66c3d6b4089d8'),
(212, 53, 'flexible_template_0_bg_img', ''),
(213, 53, '_flexible_template_0_bg_img', 'field_66c3d6df089d9'),
(214, 53, 'meta_desc', 'fjkdlsjfklsdj flkjsd lfkjsd lfksjd flskdj flsdk fjlsdk ffj dklsj fkldsj klfjs dkljfkldsj lkfj jfklds jflkds jfkldsfj dklsj dksfdkfs dkljdklsj dklfjs dklfjdl'),
(215, 53, '_meta_desc', 'field_66c785b395997'),
(216, 53, 'keywords', '4'),
(217, 53, '_keywords', 'field_66c7860695998'),
(218, 53, 'keywords_0_keyword', 'fdsfs'),
(219, 53, '_keywords_0_keyword', 'field_66c7862d95999'),
(220, 53, 'keywords_1_keyword', 'fsdfds'),
(221, 53, '_keywords_1_keyword', 'field_66c7862d95999'),
(222, 53, 'keywords_2_keyword', 'sdfdsfs'),
(223, 53, '_keywords_2_keyword', 'field_66c7862d95999'),
(224, 53, 'keywords_3_keyword', 'fdsfsd'),
(225, 53, '_keywords_3_keyword', 'field_66c7862d95999'),
(230, 56, 'flexible_template_0_headline', 'Unlock the <strong>power</strong> of your data'),
(231, 56, '_flexible_template_0_headline', 'field_66bb9f31e6ce1'),
(232, 56, 'flexible_template_0_subline', 'Transform <a href="/tools/">excel challenges into solutions</a> with expert automation'),
(233, 56, '_flexible_template_0_subline', 'field_66bb9f58e6ce2'),
(234, 56, 'flexible_template', 'a:1:{i:0;s:4:"hero";}'),
(235, 56, '_flexible_template', 'field_66bb9f06e6ce0'),
(236, 56, 'flexible_template_0_cta', ''),
(237, 56, '_flexible_template_0_cta', 'field_66c3d5c929e86'),
(238, 56, 'flexible_template_0_extra_cta', ''),
(239, 56, '_flexible_template_0_extra_cta', 'field_66c3d5e429e87'),
(240, 56, 'flexible_template_0_image_type', 'full'),
(241, 56, '_flexible_template_0_image_type', 'field_66c3d6b4089d8'),
(242, 56, 'flexible_template_0_bg_img', ''),
(243, 56, '_flexible_template_0_bg_img', 'field_66c3d6df089d9'),
(244, 56, 'meta_desc', 'fjkdlsjfklsdj flkjsd lfkjsd lfksjd flskdj flsdk fjlsdk ffj dklsj fkldsj klfjs dkljfkldsj lkfj jfklds jflkds jfkldsfj dklsj dksfdkfs dkljdklsj dklfjs dklfjdl'),
(245, 56, '_meta_desc', 'field_66c785b395997'),
(246, 56, 'keywords', '4'),
(247, 56, '_keywords', 'field_66c7860695998'),
(248, 56, 'keywords_0_keyword', 'fdsfs'),
(249, 56, '_keywords_0_keyword', 'field_66c7862d95999') ;
INSERT INTO `wper_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(250, 56, 'keywords_1_keyword', 'fsdfds'),
(251, 56, '_keywords_1_keyword', 'field_66c7862d95999'),
(252, 56, 'keywords_2_keyword', 'sdfdsfs'),
(253, 56, '_keywords_2_keyword', 'field_66c7862d95999'),
(254, 56, 'keywords_3_keyword', 'fdsfsd'),
(255, 56, '_keywords_3_keyword', 'field_66c7862d95999'),
(264, 58, '_edit_lock', '1724903746:2'),
(265, 58, '_edit_last', '2'),
(266, 58, '_wp_page_template', 'templates/resources.php'),
(267, 58, 'meta_desc', ''),
(268, 58, '_meta_desc', 'field_66c785b395997'),
(269, 58, 'keywords', ''),
(270, 58, '_keywords', 'field_66c7860695998'),
(271, 58, 'flexible_template', ''),
(272, 58, '_flexible_template', 'field_66bb9f06e6ce0'),
(279, 14, 'keywords_0_keyword', 'VBA conditional compilation'),
(280, 14, '_keywords_0_keyword', 'field_66c7862d95999'),
(281, 14, 'keywords_1_keyword', 'Office version compatibility'),
(282, 14, '_keywords_1_keyword', 'field_66c7862d95999'),
(283, 14, 'keywords_2_keyword', 'Win64 VBA constant'),
(284, 14, '_keywords_2_keyword', 'field_66c7862d95999'),
(285, 14, 'keywords_3_keyword', 'Debugging VBA code'),
(286, 14, '_keywords_3_keyword', 'field_66c7862d95999'),
(289, 62, '_acf_changed', '1'),
(290, 63, '_edit_lock', '1724628444:2'),
(291, 63, '_edit_last', '2'),
(292, 63, '_wp_page_template', 'templates/template-flexible.php'),
(293, 63, 'meta_desc', ''),
(294, 63, '_meta_desc', 'field_66c785b395997'),
(295, 63, 'keywords', ''),
(296, 63, '_keywords', 'field_66c7860695998'),
(297, 63, 'flexible_template', ''),
(298, 63, '_flexible_template', 'field_66bb9f06e6ce0'),
(299, 64, 'meta_desc', ''),
(300, 64, '_meta_desc', 'field_66c785b395997'),
(301, 64, 'keywords', ''),
(302, 64, '_keywords', 'field_66c7860695998'),
(303, 64, 'flexible_template', ''),
(304, 64, '_flexible_template', 'field_66bb9f06e6ce0'),
(305, 63, '_wp_trash_meta_status', 'publish'),
(306, 63, '_wp_trash_meta_time', '1724628587'),
(307, 63, '_wp_desired_post_slug', 'test'),
(308, 1, '_edit_lock', '1724688400:2'),
(309, 67, '_edit_lock', '1724688894:2'),
(310, 67, '_edit_last', '2'),
(311, 67, 'meta_desc', 'Hello hi'),
(312, 67, '_meta_desc', 'field_66c785b395997'),
(313, 67, 'keywords', ''),
(314, 67, '_keywords', 'field_66c7860695998'),
(315, 67, 'flexible_resource_0_wysiwyg', 'fdsfsfsdfsfdsfsd'),
(316, 67, '_flexible_resource_0_wysiwyg', 'field_66c783907bf01'),
(317, 67, 'flexible_resource', 'a:1:{i:0;s:7:"wysiwyg";}'),
(318, 67, '_flexible_resource', 'field_66c783567bf00'),
(319, 67, '_wp_old_date', '2024-08-26'),
(320, 67, '_thumbnail_id', '35'),
(321, 68, '_edit_lock', '1724688886:2'),
(322, 68, '_edit_last', '2'),
(323, 68, '_thumbnail_id', '36'),
(324, 68, 'meta_desc', 'Hello!'),
(325, 68, '_meta_desc', 'field_66c785b395997'),
(326, 68, 'keywords', ''),
(327, 68, '_keywords', 'field_66c7860695998'),
(328, 68, 'flexible_resource_0_wysiwyg', 'Beep boop beep'),
(329, 68, '_flexible_resource_0_wysiwyg', 'field_66c783907bf01'),
(330, 68, 'flexible_resource', 'a:1:{i:0;s:7:"wysiwyg";}'),
(331, 68, '_flexible_resource', 'field_66c783567bf00'),
(332, 69, '_edit_lock', '1724689994:2'),
(333, 69, '_edit_last', '2'),
(334, 69, '_thumbnail_id', '33'),
(335, 69, 'meta_desc', 'Howdy hey'),
(336, 69, '_meta_desc', 'field_66c785b395997'),
(337, 69, 'keywords', ''),
(338, 69, '_keywords', 'field_66c7860695998'),
(339, 69, 'flexible_resource_0_wysiwyg', 'Woo!'),
(340, 69, '_flexible_resource_0_wysiwyg', 'field_66c783907bf01'),
(341, 69, 'flexible_resource', 'a:1:{i:0;s:7:"wysiwyg";}'),
(342, 69, '_flexible_resource', 'field_66c783567bf00'),
(343, 70, '_edit_lock', '1724708563:2'),
(344, 70, '_edit_last', '2'),
(345, 70, '_thumbnail_id', '34'),
(346, 70, 'meta_desc', 'Howdy hey'),
(347, 70, '_meta_desc', 'field_66c785b395997'),
(348, 70, 'keywords', ''),
(349, 70, '_keywords', 'field_66c7860695998'),
(350, 70, 'flexible_resource_0_wysiwyg', 'Woo!'),
(351, 70, '_flexible_resource_0_wysiwyg', 'field_66c783907bf01'),
(352, 70, 'flexible_resource', 'a:1:{i:0;s:7:"wysiwyg";}'),
(353, 70, '_flexible_resource', 'field_66c783567bf00'),
(354, 70, '_wp_old_slug', 'hi-there'),
(355, 71, '_edit_lock', '1724813984:2'),
(356, 71, '_edit_last', '2'),
(357, 74, '_edit_lock', '1724821936:2'),
(358, 74, '_edit_last', '2'),
(359, 58, 'flexible_resources_0_post_type', 'resource'),
(360, 58, '_flexible_resources_0_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(361, 58, 'flexible_resources', 'a:2:{i:0;s:8:"featured";i:1;s:8:"featured";}'),
(362, 58, '_flexible_resources', 'field_66ccf77447809'),
(393, 3, '_edit_lock', '1724712831:2'),
(394, 58, 'flexible_resources_0_', ''),
(395, 58, '_flexible_resources_0_', 'field_66ccf7ff4780a_field_66cd21dd4c85b') ;
INSERT INTO `wper_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(396, 58, 'flexible_resources_0_taxonomy', ''),
(397, 58, '_flexible_resources_0_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(426, 58, 'flexible_resources_0_post_taxonomy', '9'),
(427, 58, '_flexible_resources_0_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(430, 58, 'flexible_resources_1_post_taxonomy', '1'),
(431, 58, '_flexible_resources_1_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(852, 58, 'flexible_resources_0_taxonomy_test', ''),
(853, 58, '_flexible_resources_0_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(854, 58, 'flexible_resources_1_taxonomy_test', ''),
(855, 58, '_flexible_resources_1_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(880, 58, 'flexible_resources_0_resource_type', 'a:2:{i:0;s:1:"9";i:1;s:2:"10";}'),
(881, 58, '_flexible_resources_0_resource_type', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(882, 110, 'meta_desc', ''),
(883, 110, '_meta_desc', 'field_66c785b395997'),
(884, 110, 'keywords', ''),
(885, 110, '_keywords', 'field_66c7860695998'),
(886, 110, 'flexible_template', ''),
(887, 110, '_flexible_template', 'field_66bb9f06e6ce0'),
(888, 110, 'flexible_resources_0_post_type', 'resource'),
(889, 110, '_flexible_resources_0_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(890, 110, 'flexible_resources', 'a:2:{i:0;s:8:"featured";i:1;s:8:"featured";}'),
(891, 110, '_flexible_resources', 'field_66ccf77447809'),
(892, 110, 'flexible_resources_0_', ''),
(893, 110, '_flexible_resources_0_', 'field_66ccf7ff4780a_field_66cd21dd4c85b'),
(894, 110, 'flexible_resources_0_taxonomy', ''),
(895, 110, '_flexible_resources_0_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(896, 110, 'flexible_resources_0_post_taxonomy', '9'),
(897, 110, '_flexible_resources_0_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(898, 110, 'flexible_resources_1_post_type', 'a:1:{i:0;s:1:"1";}'),
(899, 110, '_flexible_resources_1_post_type', 'field_66ccf7ff4780a_field_66cd4c16b6b0c'),
(900, 110, 'flexible_resources_1_post_taxonomy', '1'),
(901, 110, '_flexible_resources_1_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(902, 110, 'flexible_resources_0_taxonomy_test', ''),
(903, 110, '_flexible_resources_0_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(904, 110, 'flexible_resources_1_taxonomy_test', ''),
(905, 110, '_flexible_resources_1_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(906, 110, 'flexible_resources_0_resource_type', ''),
(907, 110, '_flexible_resources_0_resource_type', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(908, 111, '_edit_lock', '1724953826:2'),
(909, 111, '_edit_last', '2'),
(910, 111, '_thumbnail_id', '37'),
(911, 111, 'meta_desc', 'Here\'s a meta description, or regular description, of your mom.'),
(912, 111, '_meta_desc', 'field_66c785b395997'),
(913, 111, 'keywords', ''),
(914, 111, '_keywords', 'field_66c7860695998'),
(915, 111, 'flexible_resource_0_wysiwyg', 'fdsfsfsdfsfs'),
(916, 111, '_flexible_resource_0_wysiwyg', 'field_66c783907bf01'),
(917, 111, 'flexible_resource', 'a:1:{i:0;s:7:"wysiwyg";}'),
(918, 111, '_flexible_resource', 'field_66c783567bf00'),
(919, 112, 'meta_desc', ''),
(920, 112, '_meta_desc', 'field_66c785b395997'),
(921, 112, 'keywords', ''),
(922, 112, '_keywords', 'field_66c7860695998'),
(923, 112, 'flexible_template', ''),
(924, 112, '_flexible_template', 'field_66bb9f06e6ce0'),
(925, 112, 'flexible_resources_0_post_type', 'resource'),
(926, 112, '_flexible_resources_0_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(927, 112, 'flexible_resources', 'a:1:{i:0;s:8:"featured";}'),
(928, 112, '_flexible_resources', 'field_66ccf77447809'),
(929, 112, 'flexible_resources_0_', ''),
(930, 112, '_flexible_resources_0_', 'field_66ccf7ff4780a_field_66cd21dd4c85b'),
(931, 112, 'flexible_resources_0_taxonomy', ''),
(932, 112, '_flexible_resources_0_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(933, 112, 'flexible_resources_0_post_taxonomy', '9'),
(934, 112, '_flexible_resources_0_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(935, 112, 'flexible_resources_1_post_taxonomy', '1'),
(936, 112, '_flexible_resources_1_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(937, 112, 'flexible_resources_0_taxonomy_test', ''),
(938, 112, '_flexible_resources_0_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(939, 112, 'flexible_resources_1_taxonomy_test', ''),
(940, 112, '_flexible_resources_1_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(941, 112, 'flexible_resources_0_resource_type', 'a:1:{i:0;s:1:"9";}'),
(942, 112, '_flexible_resources_0_resource_type', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(943, 113, 'meta_desc', ''),
(944, 113, '_meta_desc', 'field_66c785b395997'),
(945, 113, 'keywords', ''),
(946, 113, '_keywords', 'field_66c7860695998'),
(947, 113, 'flexible_template', ''),
(948, 113, '_flexible_template', 'field_66bb9f06e6ce0'),
(949, 113, 'flexible_resources_0_post_type', 'resource'),
(950, 113, '_flexible_resources_0_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(951, 113, 'flexible_resources', 'a:1:{i:0;s:8:"featured";}'),
(952, 113, '_flexible_resources', 'field_66ccf77447809'),
(953, 113, 'flexible_resources_0_', ''),
(954, 113, '_flexible_resources_0_', 'field_66ccf7ff4780a_field_66cd21dd4c85b'),
(955, 113, 'flexible_resources_0_taxonomy', ''),
(956, 113, '_flexible_resources_0_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(957, 113, 'flexible_resources_0_post_taxonomy', '9'),
(958, 113, '_flexible_resources_0_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(959, 113, 'flexible_resources_1_post_taxonomy', '1'),
(960, 113, '_flexible_resources_1_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(961, 113, 'flexible_resources_0_taxonomy_test', ''),
(962, 113, '_flexible_resources_0_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(963, 113, 'flexible_resources_1_taxonomy_test', ''),
(964, 113, '_flexible_resources_1_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(965, 113, 'flexible_resources_0_resource_type', 'a:2:{i:0;s:1:"9";i:1;s:2:"10";}'),
(966, 113, '_flexible_resources_0_resource_type', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(967, 58, 'flexible_resources_0_resource_tax', 'a:2:{i:0;s:1:"9";i:1;s:2:"10";}'),
(968, 58, '_flexible_resources_0_resource_tax', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(969, 58, 'flexible_resources_1_post_type', 'post') ;
INSERT INTO `wper_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(970, 58, '_flexible_resources_1_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(971, 58, 'flexible_resources_1_post_tax', 'a:1:{i:0;s:1:"1";}'),
(972, 58, '_flexible_resources_1_post_tax', 'field_66ccf7ff4780a_field_66cd4c16b6b0c'),
(973, 114, 'meta_desc', ''),
(974, 114, '_meta_desc', 'field_66c785b395997'),
(975, 114, 'keywords', ''),
(976, 114, '_keywords', 'field_66c7860695998'),
(977, 114, 'flexible_template', ''),
(978, 114, '_flexible_template', 'field_66bb9f06e6ce0'),
(979, 114, 'flexible_resources_0_post_type', 'resource'),
(980, 114, '_flexible_resources_0_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(981, 114, 'flexible_resources', 'a:2:{i:0;s:8:"featured";i:1;s:8:"featured";}'),
(982, 114, '_flexible_resources', 'field_66ccf77447809'),
(983, 114, 'flexible_resources_0_', ''),
(984, 114, '_flexible_resources_0_', 'field_66ccf7ff4780a_field_66cd21dd4c85b'),
(985, 114, 'flexible_resources_0_taxonomy', ''),
(986, 114, '_flexible_resources_0_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(987, 114, 'flexible_resources_0_post_taxonomy', '9'),
(988, 114, '_flexible_resources_0_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(989, 114, 'flexible_resources_1_post_taxonomy', '1'),
(990, 114, '_flexible_resources_1_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(991, 114, 'flexible_resources_0_taxonomy_test', ''),
(992, 114, '_flexible_resources_0_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(993, 114, 'flexible_resources_1_taxonomy_test', ''),
(994, 114, '_flexible_resources_1_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(995, 114, 'flexible_resources_0_resource_type', 'a:2:{i:0;s:1:"9";i:1;s:2:"10";}'),
(996, 114, '_flexible_resources_0_resource_type', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(997, 114, 'flexible_resources_0_resource_tax', 'a:2:{i:0;s:1:"9";i:1;s:2:"10";}'),
(998, 114, '_flexible_resources_0_resource_tax', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(999, 114, 'flexible_resources_1_post_type', 'post'),
(1000, 114, '_flexible_resources_1_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(1001, 114, 'flexible_resources_1_post_tax', 'a:1:{i:0;s:1:"1";}'),
(1002, 114, '_flexible_resources_1_post_tax', 'field_66ccf7ff4780a_field_66cd4c16b6b0c'),
(1003, 115, 'meta_desc', ''),
(1004, 115, '_meta_desc', 'field_66c785b395997'),
(1005, 115, 'keywords', ''),
(1006, 115, '_keywords', 'field_66c7860695998'),
(1007, 115, 'flexible_template', ''),
(1008, 115, '_flexible_template', 'field_66bb9f06e6ce0'),
(1009, 115, 'flexible_resources_0_post_type', 'resource'),
(1010, 115, '_flexible_resources_0_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(1011, 115, 'flexible_resources', 'a:2:{i:0;s:8:"featured";i:1;s:8:"featured";}'),
(1012, 115, '_flexible_resources', 'field_66ccf77447809'),
(1013, 115, 'flexible_resources_0_', ''),
(1014, 115, '_flexible_resources_0_', 'field_66ccf7ff4780a_field_66cd21dd4c85b'),
(1015, 115, 'flexible_resources_0_taxonomy', ''),
(1016, 115, '_flexible_resources_0_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(1017, 115, 'flexible_resources_0_post_taxonomy', '9'),
(1018, 115, '_flexible_resources_0_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(1019, 115, 'flexible_resources_1_post_taxonomy', '1'),
(1020, 115, '_flexible_resources_1_post_taxonomy', 'field_66ccf7ff4780a_field_66ccfba197d3b'),
(1021, 115, 'flexible_resources_0_taxonomy_test', ''),
(1022, 115, '_flexible_resources_0_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(1023, 115, 'flexible_resources_1_taxonomy_test', ''),
(1024, 115, '_flexible_resources_1_taxonomy_test', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(1025, 115, 'flexible_resources_0_resource_type', 'a:2:{i:0;s:1:"9";i:1;s:2:"10";}'),
(1026, 115, '_flexible_resources_0_resource_type', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(1027, 115, 'flexible_resources_0_resource_tax', 'a:2:{i:0;s:1:"9";i:1;s:2:"10";}'),
(1028, 115, '_flexible_resources_0_resource_tax', 'field_66ccf7ff4780a_field_66cd48bffbcd8'),
(1029, 115, 'flexible_resources_1_post_type', 'post'),
(1030, 115, '_flexible_resources_1_post_type', 'field_66ccf7ff4780a_field_66ccfacb97d39'),
(1031, 115, 'flexible_resources_1_post_tax', 'a:1:{i:0;s:1:"1";}'),
(1032, 115, '_flexible_resources_1_post_tax', 'field_66ccf7ff4780a_field_66cd4c16b6b0c'),
(1039, 14, 'flexible_resource_1_language', 'vba'),
(1040, 14, '_flexible_resource_1_language', 'field_66d0fc75f51ea'),
(1041, 14, 'flexible_resource_1_code', '#If Win64 Then\r\n    Debug.Print "Is Win64"\r\n#End If\r\n#If Not Win64 Then\r\n    Debug.Print "Is not Win64"\r\n#End If'),
(1042, 14, '_flexible_resource_1_code', 'field_66cbadf828998'),
(1043, 14, 'flexible_resource_2_wysiwyg', 'If the conditional compilation comparison function operated as expected, if <code>Win64</code> is <strong>0</strong> then <code>Win64</code> will be printed and if <code>Win64</code> is <strong>1</strong> then <code>Not Win64</code> will be printed.\r\n\r\nBut this is not the case. If <code>Win64</code> is <strong>0</strong> then <code>Not Win64</code> will print and if <code>Win64</code> is <strong>1</strong> then both <code>Win64</code> and <code>Not Win64</code> will print.\r\n\r\nEffectively, the <code>Not</code> condition will always be true because the test is <code>If Win64 &lt;&gt; -1</code> versus the correct <code>If Win64 = 0</code>.'),
(1044, 14, '_flexible_resource_2_wysiwyg', 'field_66c783907bf01'),
(1051, 14, 'flexible_resource_0_wysiwyg', '<strong>Summary</strong>\r\n\r\nConditional compilation allows us to control what code is compiled and run depending on environmental or situational sensitive attributes such as whether we are running on a Windows or Mac operating system, in a debugging or production mode, or running in a 32 or 64 bit environment. But the way conditional compilation directives function, built-in constants such as VBA7 and Win64 are presented as Boolean values but they are not which can lead to confusing results.\r\n\r\n<strong>Conditional Compilation</strong>\r\n\r\nFor a long time now, VBA for Office has provided support for conditional compilation. Conditional compilation lets you selectively compile specific lines of code. Below are some reasons for doing this.\r\n<ul>\r\n 	<li>Your application needs to run in different versions of Office and there are differences in the object model between the versions, and code that may compile in one version will not in another.</li>\r\n 	<li>Your application needs to run in both 32 bit and 64 bit Office.</li>\r\n 	<li>You want to develop using early binding to get the benefits of VBE\'s Intellisense but you want to distribute code that uses late binding to avoid having to ship with library references and thus avoid library version issues.</li>\r\n 	<li>You want to distribute a testing version of your application with ample debugging code in place to detect and log status information and anomalous behavior, but want to distribute a production version that excludes the majority of debugging code to optimize performance.</li>\r\n</ul>\r\nWithout conditional compilation, doing the above means either having different code projects or commenting and uncommenting a lot of code to create the different versions. The advantage of conditional compilation is that all versions of the code can co-exist in the same project. Conditionally compiled code is encapsulated in special <code>#If…#Else…#End If</code> directives where the <code>#If</code> directive uses one or more conditional compilation constants to determine whether or not the code within the <code>#If…#End If</code> is compiled. Note that the <code>#If</code> directive is not the same as the compiled <code>If</code> statement—all conditional compilation directives are preceded with a pound sign or hash tag.\r\n\r\nWhen evaluating a conditional compilation constant with a <code>#If</code> directive, if the constant has not been defined then the test will not fail but always return a negative result. This makes conditional compilation directives work across all versions of Office, and allows us to conditionally use code that works in one version of Office where the constant is defined and not use that code in another version of Office where the constant is either not defined or is defined as <strong>0</strong>.\r\n\r\n<strong>Conditional Compilation Constants</strong>\r\n\r\nA conditional compilation constant is a named <code>variable</code> set to an integer value. The most commonly used values are <strong>0</strong> (False) and <strong>-1</strong> (True). Conditional compilation constants are defined one of three ways:\r\n<ul>\r\n 	<li>In the <strong>Project Properties</strong> dialog box. When defined here the constant is available in all modules in the project.</li>\r\n 	<li>In the command line when the workbook is opened. When defined here the constant is available in all modules in the project.</li>\r\n 	<li>Using the <code>#Const</code> directive in a code module. When defined this way the constant is only available in the module in which it is declared.</li>\r\n</ul>\r\nMore detailed information on how to define conditional compilation constants is presented here.\r\nVBA provides some built in conditional compilation constants that allow conditional compilation determinant on environmental characteristics such as whether the installation is 32 or 64 bit or if the installation is Windows or Mac. A description of these constants is presented here.\r\n\r\n<strong>Using Conditional Compilation</strong>\r\n\r\nBesides the basic mechanics of the <code>#If…#Else…#End If</code> directives and defining the conditional compilation constants, how the #If evaluates the constants is where this discussion gets interesting. If you are not careful, the results may be unexpected. And the results are not always obvious since the condition determines what is compiled, not how the code functions when run.\r\n\r\n<strong>What, Exactly, Is a Conditional Compilation Constant?</strong>\r\n\r\nThis is where things start to get confusing. The conditional compilation constant is essentially an undefined type. When entered using the <strong>Project Properties</strong> dialog it has to be an integer from <strong>-32768</strong> to <strong>32767</strong> (no thousands separators.) When defined using the <code>#Const</code> directive it can be anything such an integer of any size, a real, a Boolean (True or False,) or a string.\r\n\r\nFurther, when using the <strong>Project Properties</strong> dialog to define conditional compilation constants, any value less than <strong>-9999</strong> is saved but is not restored in the text edit field when the dialog is re-displayed.\r\n\r\n<strong>The Boolean Test</strong>\r\n\r\nThe Boolean test is where conditional compilation really breaks down. Most systems including Excel formulas on the worksheet and VBA code evaluate Boolean tests as an examination of a numeric value (strings generate an error) where a value of <strong>0</strong> is False and any non-zero value is True. Effectively any value equal to <strong>0</strong> is False and any value not equal to <strong>0</strong> is True.\r\n\r\nBut the VBA conditional compilation function does not operate this way. It evaluates any value not equal to 0 as True and any value not equal to <strong>-1</strong> as False. What this means is that any value other than <strong>0</strong> or <strong>-1</strong> is going to result in a positive outcome whether or not the <code>Not</code> operator is used.\r\n\r\n<strong>Why Is The Faulty Boolean Test An Issue?</strong>\r\n\r\nThe conditional compilation Boolean test is only an issue if the constant is presented as a Boolean value and you evaluate it as a Boolean in a test condition. Unfortunately, this is the case with all predefined constants: Microsoft defined them as set to a <strong>0</strong> or a <strong>1</strong>. Let’s look at a specific example using the Win64 predefined constant'),
(1052, 14, '_flexible_resource_0_wysiwyg', 'field_66c783907bf01'),
(1055, 119, '_edit_last', '2'),
(1056, 119, '_wp_page_template', 'default'),
(1057, 119, 'meta_desc', ''),
(1058, 119, '_meta_desc', 'field_66c785b395997'),
(1059, 119, 'keywords', ''),
(1060, 119, '_keywords', 'field_66c7860695998'),
(1061, 120, 'meta_desc', ''),
(1062, 120, '_meta_desc', 'field_66c785b395997'),
(1063, 120, 'keywords', ''),
(1064, 120, '_keywords', 'field_66c7860695998'),
(1065, 119, '_edit_lock', '1726625564:2') ;

#
# End of data contents of table `wper_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wper_posts`
#

DROP TABLE IF EXISTS `wper_posts`;


#
# Table structure of table `wper_posts`
#

CREATE TABLE `wper_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_posts`
#
INSERT INTO `wper_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-08-13 17:04:56', '2024-08-13 17:04:56', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2024-08-13 17:04:56', '2024-08-13 17:04:56', '', 0, 'http://localhost:10004/?p=1', 0, 'post', '', 1),
(2, 1, '2024-08-13 17:04:56', '2024-08-13 17:04:56', '<!-- wp:paragraph -->\r\n<p>Butts</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2024-08-26 22:55:49', '2024-08-26 22:55:49', '', 0, 'http://localhost:10004/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-08-13 17:04:56', '2024-08-13 17:04:56', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost:10004.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2024-08-13 17:04:56', '2024-08-13 17:04:56', '', 0, 'http://localhost:10004/?page_id=3', 0, 'page', '', 0),
(4, 0, '2024-08-13 17:05:00', '2024-08-13 17:05:00', '<!-- wp:page-list /-->', 'Navigation', '', 'publish', 'closed', 'closed', '', 'navigation', '', '', '2024-08-13 17:05:00', '2024-08-13 17:05:00', '', 0, 'http://localhost:10004/2024/08/13/navigation/', 0, 'wp_navigation', '', 0),
(6, 1, '2024-08-13 17:57:27', '2024-08-13 17:57:27', '{"version":3,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentyfour', '', '', '2024-08-13 17:57:27', '2024-08-13 17:57:27', '', 0, 'http://localhost:10004/2024/08/13/wp-global-styles-twentytwentyfour/', 0, 'wp_global_styles', '', 0),
(7, 1, '2024-08-13 17:58:15', '2024-08-13 17:58:15', '{"version":3,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-zorvek', '', '', '2024-08-13 17:58:15', '2024-08-13 17:58:15', '', 0, 'http://localhost:10004/2024/08/13/wp-global-styles-zorvek/', 0, 'wp_global_styles', '', 0),
(9, 1, '2024-08-13 18:01:14', '2024-08-13 18:01:14', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:31:"templates/template-flexible.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Flexible Template', 'flexible-template', 'publish', 'closed', 'closed', '', 'group_66bb9f060beb9', '', '', '2024-08-25 23:16:11', '2024-08-25 23:16:11', '', 0, 'http://localhost:10004/?post_type=acf-field-group&#038;p=9', 0, 'acf-field-group', '', 0),
(10, 1, '2024-08-13 18:01:13', '2024-08-13 18:01:13', 'a:10:{s:10:"aria-label";s:0:"";s:4:"type";s:16:"flexible_content";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"layouts";a:2:{s:20:"layout_66bb9f158d434";a:6:{s:3:"key";s:20:"layout_66bb9f158d434";s:5:"label";s:4:"Hero";s:4:"name";s:4:"hero";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}s:20:"layout_66c3d7e856461";a:6:{s:3:"key";s:20:"layout_66c3d7e856461";s:5:"label";s:5:"Table";s:4:"name";s:5:"table";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}}s:3:"min";s:0:"";s:3:"max";s:0:"";s:12:"button_label";s:7:"Add Row";}', 'Flexible Template', 'flexible_template', 'publish', 'closed', 'closed', '', 'field_66bb9f06e6ce0', '', '', '2024-08-19 23:40:44', '2024-08-19 23:40:44', '', 9, 'http://localhost:10004/?post_type=acf-field&#038;p=10', 0, 'acf-field', '', 0),
(11, 1, '2024-08-13 18:01:13', '2024-08-13 18:01:13', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:10:"shortstack";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66bb9f158d434";s:13:"default_value";s:0:"";s:4:"tabs";s:6:"visual";s:7:"toolbar";s:5:"basic";s:12:"media_upload";i:0;s:5:"delay";i:0;}', 'Headline', 'headline', 'publish', 'closed', 'closed', '', 'field_66bb9f31e6ce1', '', '', '2024-08-13 18:01:13', '2024-08-13 18:01:13', '', 10, 'http://localhost:10004/?post_type=acf-field&p=11', 0, 'acf-field', '', 0),
(12, 1, '2024-08-13 18:01:13', '2024-08-13 18:01:13', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:8:"medstack";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66bb9f158d434";s:13:"default_value";s:0:"";s:4:"tabs";s:6:"visual";s:7:"toolbar";s:5:"basic";s:12:"media_upload";i:0;s:5:"delay";i:0;}', 'Subline', 'subline', 'publish', 'closed', 'closed', '', 'field_66bb9f58e6ce2', '', '', '2024-08-13 18:01:13', '2024-08-13 18:01:13', '', 10, 'http://localhost:10004/?post_type=acf-field&p=12', 1, 'acf-field', '', 0),
(14, 2, '2024-08-17 22:03:23', '2024-08-17 22:03:23', 'Butts', 'That Whacky Conditional Compiler Argument', '', 'publish', 'closed', 'closed', '', 'test', '', '', '2024-08-30 14:40:36', '2024-08-30 14:40:36', '', 0, 'http://localhost:10004/?post_type=resource&#038;p=14', 0, 'resource', '', 0),
(18, 2, '2024-08-17 22:42:43', '2024-08-17 22:42:43', '', 'dog typing', '', 'inherit', 'open', 'closed', '', 'dog-typing', '', '', '2024-08-17 22:42:43', '2024-08-17 22:42:43', '', 14, 'http://localhost:10004/wp-content/uploads/2024/08/dog-typing.jpeg', 0, 'attachment', 'image/jpeg', 0),
(24, 2, '2024-08-19 23:37:13', '2024-08-19 23:37:13', 'a:15:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66bb9f158d434";s:7:"choices";a:2:{s:4:"full";s:15:"Full Background";s:8:"multiple";s:19:"Collage of Multiple";}s:13:"default_value";b:0;s:13:"return_format";s:5:"value";s:8:"multiple";i:0;s:10:"allow_null";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";}', 'Image Type', 'image_type', 'publish', 'closed', 'closed', '', 'field_66c3d6b4089d8', '', '', '2024-08-25 23:16:11', '2024-08-25 23:16:11', '', 10, 'http://localhost:10004/?post_type=acf-field&#038;p=24', 2, 'acf-field', '', 0),
(25, 2, '2024-08-19 23:37:13', '2024-08-19 23:37:13', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_66c3d6b4089d8";s:8:"operator";s:2:"==";s:5:"value";s:4:"full";}}}s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66bb9f158d434";s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Background Image', 'bg_img', 'publish', 'closed', 'closed', '', 'field_66c3d6df089d9', '', '', '2024-08-25 23:16:11', '2024-08-25 23:16:11', '', 10, 'http://localhost:10004/?post_type=acf-field&#038;p=25', 3, 'acf-field', '', 0),
(26, 2, '2024-08-19 23:37:13', '2024-08-19 23:37:13', 'a:20:{s:10:"aria-label";s:0:"";s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_66c3d6b4089d8";s:8:"operator";s:2:"==";s:5:"value";s:8:"multiple";}}}s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66bb9f158d434";s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:6:"insert";s:6:"append";s:12:"preview_size";s:6:"medium";}', 'Images', 'images', 'publish', 'closed', 'closed', '', 'field_66c3d6fa089da', '', '', '2024-08-25 23:16:11', '2024-08-25 23:16:11', '', 10, 'http://localhost:10004/?post_type=acf-field&#038;p=26', 4, 'acf-field', '', 0),
(27, 2, '2024-08-19 23:40:44', '2024-08-19 23:40:44', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"table";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66c3d7e856461";s:10:"use_header";i:0;s:11:"use_caption";i:2;}', 'Table', 'table', 'publish', 'closed', 'closed', '', 'field_66c3d7ed56463', '', '', '2024-08-19 23:40:44', '2024-08-19 23:40:44', '', 10, 'http://localhost:10004/?post_type=acf-field&p=27', 0, 'acf-field', '', 0),
(30, 2, '2024-08-19 23:44:48', '2024-08-19 23:44:48', '<!-- wp:paragraph -->\r\n<p>Butts</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-08-19 23:44:48', '2024-08-19 23:44:48', '', 2, 'http://localhost:10004/?p=30', 0, 'revision', '', 0),
(31, 2, '2024-08-20 22:44:25', '2024-08-20 22:44:25', '', 'Tools', '', 'publish', 'closed', 'closed', '', 'tools', '', '', '2024-08-21 17:47:50', '2024-08-21 17:47:50', '', 0, 'http://localhost:10004/?page_id=31', 0, 'page', '', 0),
(32, 2, '2024-08-20 22:42:48', '2024-08-20 22:42:48', '', '2c87f3bbcc1aa9a14b2dcc927aabd785', '', 'inherit', 'open', 'closed', '', '2c87f3bbcc1aa9a14b2dcc927aabd785', '', '', '2024-08-20 22:43:32', '2024-08-20 22:43:32', '', 31, 'http://localhost:10004/wp-content/uploads/2024/08/2c87f3bbcc1aa9a14b2dcc927aabd785.jpg', 0, 'attachment', 'image/jpeg', 0),
(33, 2, '2024-08-20 22:42:58', '2024-08-20 22:42:58', '', '40650c5a6506cfe1b804176a8be72d0f', '', 'inherit', 'open', 'closed', '', '40650c5a6506cfe1b804176a8be72d0f', '', '', '2024-08-20 22:42:58', '2024-08-20 22:42:58', '', 31, 'http://localhost:10004/wp-content/uploads/2024/08/40650c5a6506cfe1b804176a8be72d0f.jpg', 0, 'attachment', 'image/jpeg', 0),
(34, 2, '2024-08-20 22:43:28', '2024-08-20 22:43:28', '', 'shormp', '', 'inherit', 'open', 'closed', '', 'shormp', '', '', '2024-08-20 22:43:28', '2024-08-20 22:43:28', '', 31, 'http://localhost:10004/wp-content/uploads/2024/08/shormp.jpg', 0, 'attachment', 'image/jpeg', 0),
(35, 2, '2024-08-20 22:43:53', '2024-08-20 22:43:53', '', 'oh shit', '', 'inherit', 'open', 'closed', '', 'oh-shit', '', '', '2024-08-20 22:43:53', '2024-08-20 22:43:53', '', 31, 'http://localhost:10004/wp-content/uploads/2024/08/oh-shit.jpg', 0, 'attachment', 'image/jpeg', 0),
(36, 2, '2024-08-20 22:43:59', '2024-08-20 22:43:59', '', 'gasp', '', 'inherit', 'open', 'closed', '', 'gasp', '', '', '2024-08-20 22:43:59', '2024-08-20 22:43:59', '', 31, 'http://localhost:10004/wp-content/uploads/2024/08/gasp.jpeg', 0, 'attachment', 'image/jpeg', 0),
(37, 2, '2024-08-20 22:44:10', '2024-08-20 22:44:10', '', 'don\'t with me', '', 'inherit', 'open', 'closed', '', 'dont-with-me', '', '', '2024-08-20 22:44:18', '2024-08-20 22:44:18', '', 31, 'http://localhost:10004/wp-content/uploads/2024/08/dont-with-me.jpeg', 0, 'attachment', 'image/jpeg', 0),
(38, 2, '2024-08-20 22:44:25', '2024-08-20 22:44:25', '', 'Tools', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2024-08-20 22:44:25', '2024-08-20 22:44:25', '', 31, 'http://localhost:10004/?p=38', 0, 'revision', '', 0),
(39, 2, '2024-08-22 18:31:08', '2024-08-22 18:31:08', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:8:"resource";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Single Resource', 'single-resource', 'publish', 'closed', 'closed', '', 'group_66c78355ef9ca', '', '', '2024-08-29 23:05:01', '2024-08-29 23:05:01', '', 0, 'http://localhost:10004/?post_type=acf-field-group&#038;p=39', 0, 'acf-field-group', '', 0),
(40, 2, '2024-08-22 18:31:08', '2024-08-22 18:31:08', 'a:10:{s:10:"aria-label";s:0:"";s:4:"type";s:16:"flexible_content";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"layouts";a:5:{s:20:"layout_66c783632be8e";a:6:{s:3:"key";s:20:"layout_66c783632be8e";s:5:"label";s:7:"WYSIWYG";s:4:"name";s:7:"wysiwyg";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}s:20:"layout_66c7850d7ddfa";a:6:{s:3:"key";s:20:"layout_66c7850d7ddfa";s:5:"label";s:5:"Table";s:4:"name";s:5:"table";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}s:20:"layout_66c785197ddfd";a:6:{s:3:"key";s:20:"layout_66c785197ddfd";s:5:"label";s:14:"Featured Image";s:4:"name";s:5:"image";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}s:20:"layout_66c7853e7ddff";a:6:{s:3:"key";s:20:"layout_66c7853e7ddff";s:5:"label";s:13:"File Download";s:4:"name";s:13:"file_download";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}s:20:"layout_66cbadf028996";a:6:{s:3:"key";s:20:"layout_66cbadf028996";s:5:"label";s:12:"Code Snippet";s:4:"name";s:12:"code_snippet";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}}s:3:"min";s:0:"";s:3:"max";s:0:"";s:12:"button_label";s:7:"Add Row";}', 'Flexible Resource', 'flexible_resource', 'publish', 'closed', 'closed', '', 'field_66c783567bf00', '', '', '2024-08-25 22:20:20', '2024-08-25 22:20:20', '', 39, 'http://localhost:10004/?post_type=acf-field&#038;p=40', 0, 'acf-field', '', 0),
(41, 2, '2024-08-22 18:31:08', '2024-08-22 18:31:08', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66c783632be8e";s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'WYSIWYG', 'wysiwyg', 'publish', 'closed', 'closed', '', 'field_66c783907bf01', '', '', '2024-08-22 18:31:08', '2024-08-22 18:31:08', '', 40, 'http://localhost:10004/?post_type=acf-field&p=41', 0, 'acf-field', '', 0),
(42, 2, '2024-08-22 18:31:08', '2024-08-22 18:31:08', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"table";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66c7850d7ddfa";s:10:"use_header";i:0;s:11:"use_caption";i:2;}', 'Table', 'table', 'publish', 'closed', 'closed', '', 'field_66c783a37bf02', '', '', '2024-08-22 18:38:12', '2024-08-22 18:38:12', '', 40, 'http://localhost:10004/?post_type=acf-field&#038;p=42', 0, 'acf-field', '', 0),
(43, 2, '2024-08-22 18:31:08', '2024-08-22 18:31:08', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66c785197ddfd";s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Featured Image', 'featured_image', 'publish', 'closed', 'closed', '', 'field_66c783b47bf03', '', '', '2024-08-22 18:38:12', '2024-08-22 18:38:12', '', 40, 'http://localhost:10004/?post_type=acf-field&#038;p=43', 0, 'acf-field', '', 0),
(44, 2, '2024-08-22 18:38:12', '2024-08-22 18:38:12', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"20";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66c7853e7ddff";s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'File', 'file', 'publish', 'closed', 'closed', '', 'field_66c7854d7de01', '', '', '2024-08-22 18:38:12', '2024-08-22 18:38:12', '', 40, 'http://localhost:10004/?post_type=acf-field&p=44', 0, 'acf-field', '', 0),
(45, 2, '2024-08-22 18:38:12', '2024-08-22 18:38:12', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"80";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66c7853e7ddff";s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Download Button Text', 'download_text', 'publish', 'closed', 'closed', '', 'field_66c7856f7de03', '', '', '2024-08-22 18:38:12', '2024-08-22 18:38:12', '', 40, 'http://localhost:10004/?post_type=acf-field&p=45', 1, 'acf-field', '', 0),
(46, 2, '2024-08-22 18:41:28', '2024-08-22 18:41:28', 'a:8:{s:8:"location";a:3:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:8:"resource";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}}i:2;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'SEO', 'seo', 'publish', 'closed', 'closed', '', 'group_66c785b2dd043', '', '', '2024-08-26 22:34:21', '2024-08-26 22:34:21', '', 0, 'http://localhost:10004/?post_type=acf-field-group&#038;p=46', 0, 'acf-field-group', '', 0),
(47, 2, '2024-08-22 18:41:28', '2024-08-22 18:41:28', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:16:"meta-description";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'Meta Description', 'meta_desc', 'publish', 'closed', 'closed', '', 'field_66c785b395997', '', '', '2024-08-22 18:51:27', '2024-08-22 18:51:27', '', 46, 'http://localhost:10004/?post_type=acf-field&#038;p=47', 0, 'acf-field', '', 0),
(48, 2, '2024-08-22 18:41:28', '2024-08-22 18:41:28', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:13:"meta-keywords";}s:6:"layout";s:3:"row";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";i:6;s:9:"collapsed";s:0:"";s:12:"button_label";s:11:"Add Keyword";s:13:"rows_per_page";i:20;}', 'Keywords', 'keywords', 'publish', 'closed', 'closed', '', 'field_66c7860695998', '', '', '2024-08-22 19:52:32', '2024-08-22 19:52:32', '', 46, 'http://localhost:10004/?post_type=acf-field&#038;p=48', 1, 'acf-field', '', 0),
(49, 2, '2024-08-22 18:41:28', '2024-08-22 18:41:28', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', '', 'keyword', 'publish', 'closed', 'closed', '', 'field_66c7862d95999', '', '', '2024-08-22 18:42:04', '2024-08-22 18:42:04', '', 48, 'http://localhost:10004/?post_type=acf-field&#038;p=49', 0, 'acf-field', '', 0),
(51, 2, '2024-08-22 19:30:58', '2024-08-22 19:30:58', '<!-- wp:paragraph -->\r\n<p>Butts</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-08-22 19:30:58', '2024-08-22 19:30:58', '', 2, 'http://localhost:10004/?p=51', 0, 'revision', '', 0),
(52, 2, '2024-08-22 19:31:09', '2024-08-22 19:31:09', '<!-- wp:paragraph -->\r\n<p>Butts</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-08-22 19:31:09', '2024-08-22 19:31:09', '', 2, 'http://localhost:10004/?p=52', 0, 'revision', '', 0),
(53, 2, '2024-08-22 19:34:50', '2024-08-22 19:34:50', '<!-- wp:paragraph -->\r\n<p>Butts</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-08-22 19:34:50', '2024-08-22 19:34:50', '', 2, 'http://localhost:10004/?p=53', 0, 'revision', '', 0),
(56, 2, '2024-08-23 18:57:16', '2024-08-23 18:57:16', '<!-- wp:paragraph -->\r\n<p>Butts</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-08-23 18:57:16', '2024-08-23 18:57:16', '', 2, 'http://localhost:10004/?p=56', 0, 'revision', '', 0),
(57, 2, '2024-08-25 22:20:20', '2024-08-25 22:20:20', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66cbadf028996";s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'Code', 'code', 'publish', 'closed', 'closed', '', 'field_66cbadf828998', '', '', '2024-08-29 22:58:09', '2024-08-29 22:58:09', '', 40, 'http://localhost:10004/?post_type=acf-field&#038;p=57', 1, 'acf-field', '', 0),
(58, 2, '2024-08-25 22:47:26', '2024-08-25 22:47:26', '', 'Resources', '', 'publish', 'closed', 'closed', '', 'resources', '', '', '2024-08-28 17:48:14', '2024-08-28 17:48:14', '', 0, 'http://localhost:10004/?page_id=58', 0, 'page', '', 0),
(62, 2, '2024-08-25 23:22:03', '2024-08-25 23:22:03', '<!-- wp:paragraph -->\n<p class=""><strong>Summary</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p class="">Conditional compilation allows us to control what code is compiled and run depending on environmental or situational sensitive attributes such as whether we are running on a Windows or Mac operating system, in a debugging or production mode, or running in a 32 or 64 bit environment. But the way conditional compilation directives function, built-in constants such as VBA7 and Win64 are presented as Boolean values but they are not which can lead to confusing results.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p class=""><strong>Conditional Compilation</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p class="">For a long time now, VBA for Office has provided support for conditional compilation. Conditional compilation lets you selectively compile specific lines of code. Below are some reasons for doing this.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class="wp-block-list"><!-- wp:list-item -->\n<li class="">Your application needs to run in different versions of Office and there are differences in the object model between the versions, and code that may compile in one version will not in another.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li class="">Your application needs to run in both 32 bit and 64 bit Office.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li class="">You want to develop using early binding to get the benefits of VBE\'s Intellisense but you want to distribute code that uses late binding to avoid having to ship with library references and thus avoid library version issues.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li class="">You want to distribute a testing version of your application with ample debugging code in place to detect and log status information and anomalous behavior, but want to distribute a production version that excludes the majority of debugging code to optimize performance.</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p class="">Without conditional compilation, doing the above means either having different code projects or commenting and uncommenting a lot of code to create the different versions. The advantage of conditional compilation is that all versions of the code can co-exist in the same project. Conditionally compiled code is encapsulated in special “#If…#Else…#End If” directives where the “#If” directive uses one or more conditional compilation constants to determine whether or not the code within the “#If…#End If” is compiled. Note that the “#If” directive is not the same as the compiled “If” statement—all conditional compilation directives are preceded with a pound sign or hash tag.<br>When evaluating a conditional compilation constant with a “#If” directive, if the constant has not been defined then the test will not fail but always return a negative result. This makes conditional compilation directives work across all versions of Office, and allows us to conditionally use code that works in one version of Office where the constant is defined and not use that code in another version of Office where the constant is either not defined or is defined as 0.<br>Conditional Compilation Constants<br>A conditional compilation constant is a named “variable” set to an integer value. The most commonly used values are 0 (False) and -1 (True). Conditional compilation constants are defined one of three ways:<br>In the “Project Properties” dialog box. When defined here the constant is available in all modules in the project.<br>In the command line when the workbook is opened. When defined here the constant is available in all modules in the project.<br>Using the “#Const” directive in a code module. When defined this way the constant is only available in the module in which it is declared.<br>More detailed information on how to define conditional compilation constants is presented here.<br>VBA provides some built in conditional compilation constants that allow conditional compilation determinant on environmental characteristics such as whether the installation is 32 or 64 bit or if the installation is Windows or Mac. A description of these constants is presented here.<br>Using Conditional Compilation<br>Besides the basic mechanics of the “#If…#Else…#End If” directives and defining the conditional compilation constants, how the #If evaluates the constants is where this discussion gets interesting. If you are not careful, the results may be unexpected. And the results are not always obvious since the condition determines what is compiled, not how the code functions when run.<br>What, Exactly, Is a Conditional Compilation Constant?<br>This is where things start to get confusing. The conditional compilation constant is essentially an undefined type. When entered using the “Project Properties” dialog it has to be an integer from -32768 to 32767 (no thousands separators.) When defined using the “#Const” directive it can be anything such an integer of any size, a real, a Boolean (True or False,) or a string.<br>Further, when using the “Project Properties” dialog to define conditional compilation constants, any value less than -9999 is saved but is not restored in the text edit field when the dialog is re-displayed.<br>The Boolean Test<br>The Boolean test is where conditional compilation really breaks down. Most systems including Excel formulas on the worksheet and VBA code evaluate Boolean tests as an examination of a numeric value (strings generate an error) where a value of 0 is False and any non-zero value is True. Effectively any value equal to 0 is False and any value not equal to 0 is True.<br>But the VBA conditional compilation function does not operate this way. It evaluates any value not equal to 0 as True and any value not equal to -1 as False. What this means is that any value other than 0 or -1 is going to result in a positive outcome whether or not the “Not” operator is used.<br>Why Is The Faulty Boolean Test An Issue?<br>The conditional compilation Boolean test is only an issue if the constant is presented as a Boolean value and you evaluate it as a Boolean in a test condition. Unfortunately, this is the case with all predefined constants: Microsoft defined them as set to a 0 or a 1. Let’s look at a specific example using the Win64 predefined constant<br>#If Win64 Then<br>Debug.Print "Is Win64"<br>#End If<br>#If Not Win64 Then<br>Debug.Print "Is not Win64"<br>#End If<br>If the conditional compilation comparison function operated as expected, if Win64 is 0 then “Win64” will be printed and if Win64 is 1 then “Not Win64” will be printed. But this is not the case. If Win64 is 0 then “Not Win64” will print and if Win64 is 1 then both “Win64” and “Not Win64” will print. Effectively, the “Not” condition will always be true because the test is “If Win64 &lt;&gt; -1” versus the correct “If Win64 = 0”.</p>\n<!-- /wp:paragraph -->', 'That Whacky Conditional Compiler Argument', '', 'inherit', 'closed', 'closed', '', '14-autosave-v1', '', '', '2024-08-25 23:22:03', '2024-08-25 23:22:03', '', 14, 'http://localhost:10004/?p=62', 0, 'revision', '', 0),
(63, 2, '2024-08-25 23:28:48', '2024-08-25 23:28:48', '', 'Test', '', 'trash', 'closed', 'closed', '', 'test__trashed', '', '', '2024-08-25 23:29:47', '2024-08-25 23:29:47', '', 0, 'http://localhost:10004/?page_id=63', 0, 'page', '', 0),
(64, 2, '2024-08-25 23:28:48', '2024-08-25 23:28:48', '', 'Test', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2024-08-25 23:28:48', '2024-08-25 23:28:48', '', 63, 'http://localhost:10004/?p=64', 0, 'revision', '', 0),
(65, 2, '2024-08-25 23:28:56', '2024-08-25 23:28:56', '', 'Test', '', 'inherit', 'closed', 'closed', '', '63-autosave-v1', '', '', '2024-08-25 23:28:56', '2024-08-25 23:28:56', '', 63, 'http://localhost:10004/?p=65', 0, 'revision', '', 0),
(67, 2, '2024-08-25 16:02:28', '2024-08-25 16:02:28', '', 'Beep boop', '', 'publish', 'closed', 'closed', '', 'beep-boop', '', '', '2024-08-26 16:14:53', '2024-08-26 16:14:53', '', 0, 'http://localhost:10004/?post_type=resource&#038;p=67', 0, 'resource', '', 0),
(68, 2, '2024-08-26 16:13:13', '2024-08-26 16:13:13', '', 'Testing 123 Here\'s a post!', '', 'publish', 'closed', 'closed', '', 'testing-123-heres-a-post', '', '', '2024-08-26 16:14:45', '2024-08-26 16:14:45', '', 0, 'http://localhost:10004/?post_type=resource&#038;p=68', 0, 'resource', '', 0),
(69, 2, '2024-08-26 16:14:38', '2024-08-26 16:14:38', '', 'Hi there', '', 'publish', 'closed', 'closed', '', 'hi-there', '', '', '2024-08-26 16:14:38', '2024-08-26 16:14:38', '', 0, 'http://localhost:10004/?post_type=resource&#038;p=69', 0, 'resource', '', 0),
(70, 2, '2024-08-26 16:31:23', '2024-08-26 16:31:23', '', 'Hi there BOOP', '', 'publish', 'closed', 'closed', '', 'hi-there-2', '', '', '2024-08-26 18:19:06', '2024-08-26 18:19:06', '', 0, 'http://localhost:10004/?post_type=resource&#038;p=70', 0, 'resource', '', 0),
(71, 2, '2024-08-26 21:55:04', '2024-08-26 21:55:04', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"58";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Resources Template', 'resources-template', 'publish', 'closed', 'closed', '', 'group_66ccf7745ba0c', '', '', '2024-08-27 04:00:38', '2024-08-27 04:00:38', '', 0, 'http://localhost:10004/?post_type=acf-field-group&#038;p=71', 0, 'acf-field-group', '', 0),
(72, 2, '2024-08-26 21:55:04', '2024-08-26 21:55:04', 'a:10:{s:10:"aria-label";s:0:"";s:4:"type";s:16:"flexible_content";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"layouts";a:1:{s:20:"layout_66ccf77c20c16";a:6:{s:3:"key";s:20:"layout_66ccf77c20c16";s:5:"label";s:16:"Featured Section";s:4:"name";s:8:"featured";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}}s:3:"min";s:0:"";s:3:"max";s:0:"";s:12:"button_label";s:7:"Add Row";}', 'Flexible Resources', 'flexible_resources', 'publish', 'closed', 'closed', '', 'field_66ccf77447809', '', '', '2024-08-26 21:55:04', '2024-08-26 21:55:04', '', 71, 'http://localhost:10004/?post_type=acf-field&p=72', 0, 'acf-field', '', 0),
(73, 2, '2024-08-26 21:55:04', '2024-08-26 21:55:04', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"clone";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66ccf77c20c16";s:5:"clone";a:1:{i:0;s:19:"group_66ccfac91c5fd";}s:7:"display";s:8:"seamless";s:6:"layout";s:5:"block";s:12:"prefix_label";i:0;s:11:"prefix_name";i:0;}', 'Post Selector', 'post_selector', 'publish', 'closed', 'closed', '', 'field_66ccf7ff4780a', '', '', '2024-08-26 22:07:51', '2024-08-26 22:07:51', '', 72, 'http://localhost:10004/?post_type=acf-field&#038;p=73', 0, 'acf-field', '', 0),
(74, 2, '2024-08-26 22:03:58', '2024-08-26 22:03:58', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Custom Post Type Selector', 'custom-post-type-selector', 'publish', 'closed', 'closed', '', 'group_66ccfac91c5fd', '', '', '2024-08-27 04:18:38', '2024-08-27 04:18:38', '', 0, 'http://localhost:10004/?post_type=acf-field-group&#038;p=74', 0, 'acf-field-group', '', 0),
(75, 2, '2024-08-26 22:03:58', '2024-08-26 22:03:58', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:0:{}s:13:"default_value";b:0;s:13:"return_format";s:5:"value";s:8:"multiple";i:0;s:10:"allow_null";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";}', 'Post Type', 'post_type', 'publish', 'closed', 'closed', '', 'field_66ccfacb97d39', '', '', '2024-08-27 00:51:05', '2024-08-27 00:51:05', '', 74, 'http://localhost:10004/?post_type=acf-field&#038;p=75', 0, 'acf-field', '', 0),
(107, 2, '2024-08-27 03:33:49', '2024-08-27 03:33:49', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"taxonomy";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_66ccfacb97d39";s:8:"operator";s:2:"==";s:5:"value";s:8:"resource";}}}s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:8:"taxonomy";s:5:"types";s:8:"add_term";i:1;s:10:"save_terms";i:0;s:10:"load_terms";i:0;s:13:"return_format";s:6:"object";s:10:"field_type";s:12:"multi_select";s:10:"allow_null";i:0;s:13:"bidirectional";i:0;s:8:"multiple";i:0;s:20:"bidirectional_target";a:0:{}}', 'Resource Category', 'resource_tax', 'publish', 'closed', 'closed', '', 'field_66cd48bffbcd8', '', '', '2024-08-27 04:18:38', '2024-08-27 04:18:38', '', 74, 'http://localhost:10004/?post_type=acf-field&#038;p=107', 1, 'acf-field', '', 0),
(109, 2, '2024-08-27 03:46:57', '2024-08-27 03:46:57', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"taxonomy";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_66ccfacb97d39";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:8:"taxonomy";s:8:"category";s:8:"add_term";i:1;s:10:"save_terms";i:0;s:10:"load_terms";i:0;s:13:"return_format";s:6:"object";s:10:"field_type";s:12:"multi_select";s:10:"allow_null";i:0;s:13:"bidirectional";i:0;s:8:"multiple";i:0;s:20:"bidirectional_target";a:0:{}}', 'Post Category', 'post_tax', 'publish', 'closed', 'closed', '', 'field_66cd4c16b6b0c', '', '', '2024-08-27 04:18:38', '2024-08-27 04:18:38', '', 74, 'http://localhost:10004/?post_type=acf-field&#038;p=109', 2, 'acf-field', '', 0),
(110, 2, '2024-08-27 03:47:39', '2024-08-27 03:47:39', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2024-08-27 03:47:39', '2024-08-27 03:47:39', '', 58, 'http://localhost:10004/?p=110', 0, 'revision', '', 0),
(111, 2, '2024-08-27 03:50:17', '2024-08-27 03:50:17', '', 'It\'s a Butt', '', 'publish', 'closed', 'closed', '', 'its-a-butt', '', '', '2024-08-28 20:47:26', '2024-08-28 20:47:26', '', 0, 'http://localhost:10004/?post_type=resource&#038;p=111', 0, 'resource', '', 0),
(112, 2, '2024-08-27 03:59:42', '2024-08-27 03:59:42', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2024-08-27 03:59:42', '2024-08-27 03:59:42', '', 58, 'http://localhost:10004/?p=112', 0, 'revision', '', 0),
(113, 2, '2024-08-27 04:03:04', '2024-08-27 04:03:04', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2024-08-27 04:03:04', '2024-08-27 04:03:04', '', 58, 'http://localhost:10004/?p=113', 0, 'revision', '', 0),
(114, 2, '2024-08-27 04:21:43', '2024-08-27 04:21:43', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2024-08-27 04:21:43', '2024-08-27 04:21:43', '', 58, 'http://localhost:10004/?p=114', 0, 'revision', '', 0),
(115, 2, '2024-08-28 17:48:14', '2024-08-28 17:48:14', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2024-08-28 17:48:14', '2024-08-28 17:48:14', '', 58, 'http://localhost:10004/?p=115', 0, 'revision', '', 0),
(116, 2, '2024-08-29 22:58:09', '2024-08-29 22:58:09', 'a:15:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:20:"layout_66cbadf028996";s:7:"choices";a:13:{s:3:"vba";s:18:"Visual Basic + VBA";s:5:"vbnet";s:6:"VB.Net";s:6:"csharp";s:2:"C#";s:3:"cpp";s:3:"C++";s:5:"t4-cs";s:22:"T4 Text Templates (C#)";s:9:"purebasic";s:5:"BASIC";s:6:"aspnet";s:12:"ASP.NET (C#)";s:5:"razor";s:8:"Razor C#";s:7:"graphql";s:7:"GraphQL";s:6:"markup";s:6:"Markup";s:3:"css";s:3:"CSS";s:5:"clike";s:6:"C-like";s:10:"javascript";s:10:"JavaScript";}s:13:"default_value";b:0;s:13:"return_format";s:5:"value";s:8:"multiple";i:0;s:10:"allow_null";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";}', 'Language', 'language', 'publish', 'closed', 'closed', '', 'field_66d0fc75f51ea', '', '', '2024-08-29 23:05:01', '2024-08-29 23:05:01', '', 40, 'http://localhost:10004/?post_type=acf-field&#038;p=116', 0, 'acf-field', '', 0),
(117, 2, '2024-09-18 01:18:35', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-09-18 01:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost:10004/?p=117', 0, 'post', '', 0),
(119, 2, '2024-09-18 01:53:39', '2024-09-18 01:53:39', '', 'Testing Page 2', '', 'publish', 'closed', 'closed', '', 'testing-page-2', '', '', '2024-09-18 01:53:39', '2024-09-18 01:53:39', '', 0, 'http://localhost:10004/?page_id=119', 0, 'page', '', 0),
(120, 2, '2024-09-18 01:53:39', '2024-09-18 01:53:39', '', 'Testing Page 2', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2024-09-18 01:53:39', '2024-09-18 01:53:39', '', 119, 'http://localhost:10004/?p=120', 0, 'revision', '', 0) ;

#
# End of data contents of table `wper_posts`
# --------------------------------------------------------



#
# Delete any existing table `wper_term_relationships`
#

DROP TABLE IF EXISTS `wper_term_relationships`;


#
# Table structure of table `wper_term_relationships`
#

CREATE TABLE `wper_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_term_relationships`
#
INSERT INTO `wper_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(6, 5, 0),
(7, 6, 0),
(14, 9, 0),
(67, 8, 0),
(68, 9, 0),
(69, 9, 0),
(70, 9, 0),
(111, 10, 0) ;

#
# End of data contents of table `wper_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wper_term_taxonomy`
#

DROP TABLE IF EXISTS `wper_term_taxonomy`;


#
# Table structure of table `wper_term_taxonomy`
#

CREATE TABLE `wper_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_term_taxonomy`
#
INSERT INTO `wper_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'monsterinsights_note_category', '', 0, 0),
(3, 3, 'monsterinsights_note_category', '', 0, 0),
(4, 4, 'monsterinsights_note_category', '', 0, 0),
(5, 5, 'wp_theme', '', 0, 1),
(6, 6, 'wp_theme', '', 0, 1),
(8, 8, 'types', '', 0, 1),
(9, 9, 'types', '', 0, 4),
(10, 10, 'types', '', 0, 1) ;

#
# End of data contents of table `wper_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wper_termmeta`
#

DROP TABLE IF EXISTS `wper_termmeta`;


#
# Table structure of table `wper_termmeta`
#

CREATE TABLE `wper_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_termmeta`
#

#
# End of data contents of table `wper_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wper_terms`
#

DROP TABLE IF EXISTS `wper_terms`;


#
# Table structure of table `wper_terms`
#

CREATE TABLE `wper_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_terms`
#
INSERT INTO `wper_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Website Updates', 'website-updates', 0),
(3, 'Blog Post', 'blog-post', 0),
(4, 'Promotion', 'promotion', 0),
(5, 'twentytwentyfour', 'twentytwentyfour', 0),
(6, 'zorvek', 'zorvek', 0),
(8, 'Tool', 'tool', 0),
(9, 'Walkthrough', 'walkthrough', 0),
(10, 'Thought', 'thought', 0) ;

#
# End of data contents of table `wper_terms`
# --------------------------------------------------------



#
# Delete any existing table `wper_usermeta`
#

DROP TABLE IF EXISTS `wper_usermeta`;


#
# Table structure of table `wper_usermeta`
#

CREATE TABLE `wper_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_usermeta`
#
INSERT INTO `wper_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wper_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wper_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'om-welcome-pointer,omapi_please_connect_notice'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wper_user-settings', 'editor=tinymce'),
(18, 1, 'wper_user-settings-time', '1723568821'),
(20, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:23:"acf-group_66bb9f060beb9";s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:46:"commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(21, 1, 'screen_layout_page', '2'),
(22, 2, 'nickname', 'MJ'),
(23, 2, 'first_name', 'MJ'),
(24, 2, 'last_name', 'Jones'),
(25, 2, 'description', ''),
(26, 2, 'rich_editing', 'true'),
(27, 2, 'syntax_highlighting', 'true'),
(28, 2, 'comment_shortcuts', 'false'),
(29, 2, 'admin_color', 'fresh'),
(30, 2, 'use_ssl', '0'),
(31, 2, 'show_admin_bar_front', 'true'),
(32, 2, 'locale', ''),
(33, 2, 'wper_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(34, 2, 'wper_user_level', '10'),
(35, 2, 'dismissed_wp_pointers', 'omapi_please_connect_notice'),
(37, 2, 'default_password_nag', ''),
(38, 2, 'session_tokens', 'a:1:{s:64:"91c34826d5d96ae1d60a3545c028d9cafe85ec3031c4e07387e1661c3145fb99";a:4:{s:10:"expiration";i:1726795115;s:2:"ip";s:3:"::1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";s:5:"login";i:1726622315;}}'),
(40, 2, 'meta-box-order_resource', 'a:4:{s:15:"acf_after_title";s:11:"postexcerpt";s:4:"side";s:78:"submitdiv,postimagediv,seo_checklist_meta_box,acf-group_66c785b2dd043,typesdiv";s:6:"normal";s:31:"acf-group_66c78355ef9ca,slugdiv";s:8:"advanced";s:0:"";}'),
(41, 2, 'screen_layout_resource', '2'),
(42, 2, 'wper_user-settings', 'libraryContent=browse&editor=tinymce'),
(43, 2, 'wper_user-settings-time', '1724110665'),
(44, 2, 'wper_dashboard_quick_press_last_post_id', '117'),
(45, 2, 'community-events-location', 'a:1:{s:2:"ip";s:9:"24.13.2.0";}'),
(46, 2, 'closedpostboxes_dashboard', 'a:0:{}'),
(47, 2, 'metaboxhidden_dashboard', 'a:2:{i:0;s:21:"dashboard_quick_press";i:1;s:17:"dashboard_primary";}'),
(48, 2, 'show_welcome_panel', '0'),
(49, 2, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:41:"dashboard_site_health,dashboard_right_now";s:4:"side";s:58:"dashboard_quick_press,dashboard_primary,dashboard_activity";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'),
(50, 2, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(51, 2, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:"slugdiv";}'),
(52, 2, 'manageedit-acf-ui-options-pagecolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(53, 2, 'acf_user_settings', 'a:2:{s:23:"options-pages-first-run";b:1;s:15:"show_field_keys";s:1:"1";}'),
(54, 2, 'closedpostboxes_resource', 'a:0:{}'),
(55, 2, 'metaboxhidden_resource', 'a:2:{i:0;s:11:"postexcerpt";i:1;s:7:"slugdiv";}'),
(56, 2, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:23:"acf-group_66ccf7745ba0c";s:4:"side";s:83:"submitdiv,postimagediv,seo_checklist_meta_box,acf-group_66c785b2dd043,pageparentdiv";s:6:"normal";s:59:"commentstatusdiv,commentsdiv,slugdiv,authordiv,revisionsdiv";s:8:"advanced";s:0:"";}'),
(57, 2, 'screen_layout_page', '2'),
(58, 2, 'closedpostboxes_page', 'a:0:{}'),
(59, 2, 'metaboxhidden_page', 'a:5:{i:0;s:16:"commentstatusdiv";i:1;s:11:"commentsdiv";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";i:4;s:12:"revisionsdiv";}'),
(61, 2, 'wper_persisted_preferences', 'a:3:{s:4:"core";a:2:{s:26:"isComplementaryAreaVisible";b:1;s:16:"hiddenBlockTypes";a:1:{i:0;s:21:"wonder-blocks/library";}}s:14:"core/edit-post";a:1:{s:12:"welcomeGuide";b:0;}s:9:"_modified";s:24:"2024-08-26T16:08:52.079Z";}'),
(63, 2, 'nfd_sp_last_check', '1724688545'),
(64, 3, 'nickname', 'zorvek'),
(65, 3, 'first_name', 'Kevin'),
(66, 3, 'last_name', 'Jones'),
(67, 3, 'description', ''),
(68, 3, 'rich_editing', 'true'),
(69, 3, 'syntax_highlighting', 'true'),
(70, 3, 'comment_shortcuts', 'false'),
(71, 3, 'admin_color', 'fresh'),
(72, 3, 'use_ssl', '0'),
(73, 3, 'show_admin_bar_front', 'true'),
(74, 3, 'locale', ''),
(75, 3, 'wper_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(76, 3, 'wper_user_level', '10'),
(77, 3, 'dismissed_wp_pointers', ''),
(78, 3, 'nfd_sp_last_check', '1724860120'),
(79, 2, 'wpmdb_licence_key', '97b35c37-5789-48df-abdd-59cefad7b3b6') ;

#
# End of data contents of table `wper_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wper_users`
#

DROP TABLE IF EXISTS `wper_users`;


#
# Table structure of table `wper_users`
#

CREATE TABLE `wper_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_users`
#
INSERT INTO `wper_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$Bj/hfYKKoWqzqbig5doE098BMMRtUT0', 'admin', 'admin@ehy.sgz.mybluehost.me', 'http://localhost:10004', '2024-08-13 17:04:56', '', 0, 'admin'),
(2, 'MJ', '$P$BAh52OJUIXaAZbTODLBJTMZ3s07xYS1', 'mj', 'emily@thisjones.com', '', '2024-08-14 14:13:55', '', 0, 'MJ Jones'),
(3, 'zorvek', '$P$Bl1enkyGGxhJzh1DfsdRtBMjvJgGm1/', 'zorvek', 'kjones@zorvek.com', '', '2024-08-28 15:48:39', '1724860119:$P$BQaNBr1ND09iu3dAupGG9Z9xQxOK4l.', 0, 'Kevin Jones') ;

#
# End of data contents of table `wper_users`
# --------------------------------------------------------



#
# Delete any existing table `wper_wpforms_logs`
#

DROP TABLE IF EXISTS `wper_wpforms_logs`;


#
# Table structure of table `wper_wpforms_logs`
#

CREATE TABLE `wper_wpforms_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `types` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `form_id` bigint(20) DEFAULT NULL,
  `entry_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_wpforms_logs`
#

#
# End of data contents of table `wper_wpforms_logs`
# --------------------------------------------------------



#
# Delete any existing table `wper_wpforms_payment_meta`
#

DROP TABLE IF EXISTS `wper_wpforms_payment_meta`;


#
# Table structure of table `wper_wpforms_payment_meta`
#

CREATE TABLE `wper_wpforms_payment_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_wpforms_payment_meta`
#

#
# End of data contents of table `wper_wpforms_payment_meta`
# --------------------------------------------------------



#
# Delete any existing table `wper_wpforms_payments`
#

DROP TABLE IF EXISTS `wper_wpforms_payments`;


#
# Table structure of table `wper_wpforms_payments`
#

CREATE TABLE `wper_wpforms_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `subtotal_amount` decimal(26,8) NOT NULL DEFAULT '0.00000000',
  `discount_amount` decimal(26,8) NOT NULL DEFAULT '0.00000000',
  `total_amount` decimal(26,8) NOT NULL DEFAULT '0.00000000',
  `currency` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `entry_id` bigint(20) NOT NULL DEFAULT '0',
  `gateway` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `type` varchar(12) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `mode` varchar(4) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `transaction_id` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `customer_id` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `subscription_id` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `subscription_status` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `date_created_gmt` datetime NOT NULL,
  `date_updated_gmt` datetime NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`(8)),
  KEY `total_amount` (`total_amount`),
  KEY `type` (`type`(8)),
  KEY `transaction_id` (`transaction_id`(32)),
  KEY `customer_id` (`customer_id`(32)),
  KEY `subscription_id` (`subscription_id`(32)),
  KEY `subscription_status` (`subscription_status`(8)),
  KEY `title` (`title`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_wpforms_payments`
#

#
# End of data contents of table `wper_wpforms_payments`
# --------------------------------------------------------



#
# Delete any existing table `wper_wpforms_tasks_meta`
#

DROP TABLE IF EXISTS `wper_wpforms_tasks_meta`;


#
# Table structure of table `wper_wpforms_tasks_meta`
#

CREATE TABLE `wper_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_wpforms_tasks_meta`
#
INSERT INTO `wper_wpforms_tasks_meta` ( `id`, `action`, `data`, `date`) VALUES
(1, 'wpforms_process_forms_locator_scan', 'W10=', '2024-08-13 17:06:28'),
(2, 'wpforms_admin_notifications_update', 'W10=', '2024-08-13 17:07:06') ;

#
# End of data contents of table `wper_wpforms_tasks_meta`
# --------------------------------------------------------



#
# Delete any existing table `wper_yoast_indexable`
#

DROP TABLE IF EXISTS `wper_yoast_indexable`;


#
# Table structure of table `wper_yoast_indexable`
#

CREATE TABLE `wper_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext COLLATE utf8mb4_unicode_520_ci,
  `permalink_hash` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_sub_type` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `breadcrumb_title` text COLLATE utf8mb4_unicode_520_ci,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT '0',
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext COLLATE utf8mb4_unicode_520_ci,
  `primary_focus_keyword` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT '0',
  `is_robots_noindex` tinyint(1) DEFAULT '0',
  `is_robots_nofollow` tinyint(1) DEFAULT '0',
  `is_robots_noarchive` tinyint(1) DEFAULT '0',
  `is_robots_noimageindex` tinyint(1) DEFAULT '0',
  `is_robots_nosnippet` tinyint(1) DEFAULT '0',
  `twitter_title` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_image` longtext COLLATE utf8mb4_unicode_520_ci,
  `twitter_description` longtext COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_source` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_title` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_description` longtext COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image` longtext COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_source` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_meta` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  `language` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_page_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_article_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT '0',
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT '1',
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL,
  `inclusive_language_score` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_yoast_indexable`
#

#
# End of data contents of table `wper_yoast_indexable`
# --------------------------------------------------------



#
# Delete any existing table `wper_yoast_indexable_hierarchy`
#

DROP TABLE IF EXISTS `wper_yoast_indexable_hierarchy`;


#
# Table structure of table `wper_yoast_indexable_hierarchy`
#

CREATE TABLE `wper_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_yoast_indexable_hierarchy`
#

#
# End of data contents of table `wper_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Delete any existing table `wper_yoast_migrations`
#

DROP TABLE IF EXISTS `wper_yoast_migrations`;


#
# Table structure of table `wper_yoast_migrations`
#

CREATE TABLE `wper_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wper_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_yoast_migrations`
#
INSERT INTO `wper_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404'),
(24, '20230417083836') ;

#
# End of data contents of table `wper_yoast_migrations`
# --------------------------------------------------------



#
# Delete any existing table `wper_yoast_primary_term`
#

DROP TABLE IF EXISTS `wper_yoast_primary_term`;


#
# Table structure of table `wper_yoast_primary_term`
#

CREATE TABLE `wper_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wper_yoast_primary_term`
#

#
# End of data contents of table `wper_yoast_primary_term`
# --------------------------------------------------------



#
# Delete any existing table `wper_yoast_seo_links`
#

DROP TABLE IF EXISTS `wper_yoast_seo_links`;


#
# Table structure of table `wper_yoast_seo_links`
#

CREATE TABLE `wper_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wper_yoast_seo_links`
#

#
# End of data contents of table `wper_yoast_seo_links`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

